import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  const payload = verifyToken(request);
  if (!payload) return null;
  return payload;
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const horarios = await db.horario.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(horarios);
  } catch (error) {
    console.error('Error fetching horarios:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { dia, hora, servicio, activo, orden } = body;

    if (!dia || !hora) {
      return NextResponse.json({ error: 'Día y hora son requeridos' }, { status: 400 });
    }

    const horario = await db.horario.create({
      data: {
        iglesiaId: auth.iglesiaId,
        dia,
        hora,
        servicio: servicio ?? null,
        activo: activo ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(horario, { status: 201 });
  } catch (error) {
    console.error('Error creating horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, dia, hora, servicio, activo, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const horario = await db.horario.update({
      where: { id },
      data: {
        ...(dia !== undefined && { dia }),
        ...(hora !== undefined && { hora }),
        ...(servicio !== undefined && { servicio }),
        ...(activo !== undefined && { activo }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(horario);
  } catch (error) {
    console.error('Error updating horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.horario.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}