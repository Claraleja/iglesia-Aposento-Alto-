import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const donaciones = await db.donacionConfig.findUnique({
      where: { iglesiaId: auth.iglesiaId },
    });

    return NextResponse.json(donaciones ?? null);
  } catch (error) {
    console.error('Error fetching donaciones config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const existing = await db.donacionConfig.findUnique({ where: { iglesiaId: auth.iglesiaId } });

    if (existing) {
      const updated = await db.donacionConfig.update({
        where: { id: existing.id },
        data: body,
      });
      return NextResponse.json(updated);
    }

    const created = await db.donacionConfig.create({
      data: { iglesiaId: auth.iglesiaId, ...body },
    });
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error('Error updating donaciones config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
