import { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

const JWT_SECRET = 'iglesia-digital-secret-2025';

export interface AuthPayload {
  userId: string;
  email: string;
  role: string;
  iglesiaId: string;
}

export function verifyToken(request: NextRequest): AuthPayload | null {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return null;
    const token = authHeader.substring(7);
    return jwt.verify(token, JWT_SECRET) as AuthPayload;
  } catch {
    return null;
  }
}