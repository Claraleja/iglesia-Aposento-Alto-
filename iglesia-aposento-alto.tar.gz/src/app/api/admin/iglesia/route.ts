import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

// GET: Fetch iglesia config + contacto + hero + pastor
export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const iglesia = await db.iglesia.findFirst({
      where: { id: auth.iglesiaId },
      include: { contacto: true, hero: true, pastores: { where: { activo: true } } },
    });

    if (!iglesia) {
      return NextResponse.json({ error: 'Iglesia no encontrada' }, { status: 404 });
    }

    return NextResponse.json({
      ...iglesia,
      pastor: iglesia.pastores?.[0] ?? null,
    });
  } catch (error) {
    console.error('Error fetching iglesia config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

// PUT: Update iglesia main config, contact, hero, or pastor based on `section` query param
export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const section = searchParams.get('section') || 'main';
    const body = await request.json();

    if (section === 'main') {
      const { nombre, letra, versiculo, versiculoRef, mision, logoUrl } = body;
      const iglesia = await db.iglesia.update({
        where: { id: auth.iglesiaId },
        data: {
          ...(nombre !== undefined && { nombre }),
          ...(letra !== undefined && { letra }),
          ...(versiculo !== undefined && { versiculo }),
          ...(versiculoRef !== undefined && { versiculoRef }),
          ...(mision !== undefined && { mision }),
          ...(logoUrl !== undefined && { logoUrl }),
        },
      });
      return NextResponse.json(iglesia);
    }

    if (section === 'contacto') {
      const existing = await db.iglesiaContacto.findUnique({ where: { iglesiaId: auth.iglesiaId } });
      if (existing) {
        const updated = await db.iglesiaContacto.update({
          where: { id: existing.id },
          data: body,
        });
        return NextResponse.json(updated);
      }
      const created = await db.iglesiaContacto.create({
        data: { iglesiaId: auth.iglesiaId, ...body },
      });
      return NextResponse.json(created, { status: 201 });
    }

    if (section === 'hero') {
      const existing = await db.iglesiaHero.findUnique({ where: { iglesiaId: auth.iglesiaId } });
      if (existing) {
        const updated = await db.iglesiaHero.update({
          where: { id: existing.id },
          data: body,
        });
        return NextResponse.json(updated);
      }
      const created = await db.iglesiaHero.create({
        data: { iglesiaId: auth.iglesiaId, ...body },
      });
      return NextResponse.json(created, { status: 201 });
    }

    if (section === 'pastor') {
      const existing = await db.pastor.findFirst({ where: { iglesiaId: auth.iglesiaId } });
      if (existing) {
        const updated = await db.pastor.update({
          where: { id: existing.id },
          data: body,
        });
        return NextResponse.json(updated);
      }
      const created = await db.pastor.create({
        data: { iglesiaId: auth.iglesiaId, ...body },
      });
      return NextResponse.json(created, { status: 201 });
    }

    return NextResponse.json({ error: 'Sección no válida' }, { status: 400 });
  } catch (error) {
    console.error('Error updating iglesia config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
