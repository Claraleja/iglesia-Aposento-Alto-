import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const predicas = await db.predica.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(predicas);
  } catch (error) {
    console.error('Error fetching predicas:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { titulo, serie, predicador, fechaPredica, audioUrl, spotifyUrl, imagenUrl, publicada, orden } = body;

    if (!titulo) {
      return NextResponse.json({ error: 'Título es requerido' }, { status: 400 });
    }

    const predica = await db.predica.create({
      data: {
        iglesiaId: auth.iglesiaId,
        titulo,
        serie: serie ?? 'General',
        predicador: predicador ?? '',
        fechaPredica: fechaPredica ?? '',
        audioUrl: audioUrl ?? '',
        spotifyUrl: spotifyUrl ?? '',
        imagenUrl: imagenUrl ?? '',
        publicada: publicada ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(predica, { status: 201 });
  } catch (error) {
    console.error('Error creating predica:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, titulo, serie, predicador, fechaPredica, audioUrl, spotifyUrl, imagenUrl, publicada, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const predica = await db.predica.update({
      where: { id },
      data: {
        ...(titulo !== undefined && { titulo }),
        ...(serie !== undefined && { serie }),
        ...(predicador !== undefined && { predicador }),
        ...(fechaPredica !== undefined && { fechaPredica }),
        ...(audioUrl !== undefined && { audioUrl }),
        ...(spotifyUrl !== undefined && { spotifyUrl }),
        ...(imagenUrl !== undefined && { imagenUrl }),
        ...(publicada !== undefined && { publicada }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(predica);
  } catch (error) {
    console.error('Error updating predica:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.predica.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting predica:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
