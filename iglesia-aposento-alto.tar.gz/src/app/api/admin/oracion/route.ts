import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const oracion = await db.oracionConfig.findUnique({
      where: { iglesiaId: auth.iglesiaId },
    });
    const dias = await db.oracionDia.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    const horarios = await db.oracionHorario.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });

    return NextResponse.json({ ...oracion, dias, horarios });
  } catch (error) {
    console.error('Error fetching oracion config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { dias, horarios, ...configData } = body;

    const existing = await db.oracionConfig.findUnique({ where: { iglesiaId: auth.iglesiaId } });

    if (existing) {
      await db.oracionConfig.update({
        where: { id: existing.id },
        data: configData,
      });

      if (dias !== undefined) {
        await db.oracionDia.deleteMany({ where: { iglesiaId: auth.iglesiaId } });
        if (Array.isArray(dias) && dias.length > 0) {
          await db.oracionDia.createMany({
            data: dias.map((d: { dia: string; orden?: number }) => ({
              iglesiaId: auth.iglesiaId,
              dia: d.dia,
              orden: d.orden ?? 0,
            })),
          });
        }
      }

      if (horarios !== undefined) {
        await db.oracionHorario.deleteMany({ where: { iglesiaId: auth.iglesiaId } });
        if (Array.isArray(horarios) && horarios.length > 0) {
          await db.oracionHorario.createMany({
            data: horarios.map((h: { rangoDias: string; hora: string; orden?: number }) => ({
              iglesiaId: auth.iglesiaId,
              rangoDias: h.rangoDias,
              hora: h.hora,
              orden: h.orden ?? 0,
            })),
          });
        }
      }
    } else {
      await db.oracionConfig.create({
        data: {
          iglesiaId: auth.iglesiaId,
          ...configData,
        },
      });

      if (Array.isArray(dias) && dias.length > 0) {
        await db.oracionDia.createMany({
          data: dias.map((d: { dia: string; orden?: number }) => ({
            iglesiaId: auth.iglesiaId,
            dia: d.dia,
            orden: d.orden ?? 0,
          })),
        });
      }

      if (Array.isArray(horarios) && horarios.length > 0) {
        await db.oracionHorario.createMany({
          data: horarios.map((h: { rangoDias: string; hora: string; orden?: number }) => ({
            iglesiaId: auth.iglesiaId,
            rangoDias: h.rangoDias,
            hora: h.hora,
            orden: h.orden ?? 0,
          })),
        });
      }
    }

    const result = await db.oracionConfig.findUnique({
      where: { iglesiaId: auth.iglesiaId },
    });
    const resultDias = await db.oracionDia.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    const resultHorarios = await db.oracionHorario.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });

    return NextResponse.json({ ...result, dias: resultDias, horarios: resultHorarios });
  } catch (error) {
    console.error('Error updating oracion config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
