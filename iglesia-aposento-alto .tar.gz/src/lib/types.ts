export interface IglesiaData {
  iglesia: {
    id: string;
    nombre: string;
    slug: string;
    letra: string;
    logoUrl: string;
    versiculo: string;
    versiculoRef: string;
    mision: string;
  } | null;
  contacto: {
    id: string;
    iglesiaId: string;
    direccion: string;
    telefono: string;
    email: string;
    whatsapp: string;
    facebookUrl: string;
    instagramUrl: string;
    youtubeUrl: string;
  } | null;
  hero: {
    id: string;
    iglesiaId: string;
    imagenUrl: string;
    footerSlogan: string;
    footerAnio: string;
  } | null;
  pastor: {
    id: string;
    iglesiaId: string;
    nombre: string;
    rol: string;
    iniciales: string;
    fotoUrl: string;
    bio: string;
    orden: number;
    activo: boolean;
  } | null;
  horarios: {
    id: string;
    iglesiaId: string;
    dia: string;
    servicio: string;
    hora: string;
    orden: number;
    activo: boolean;
  }[];
  predicas: {
    id: string;
    iglesiaId: string;
    titulo: string;
    serie: string;
    predicador: string;
    fechaPredica: string;
    audioUrl: string;
    spotifyUrl: string;
    imagenUrl: string;
    publicada: boolean;
    orden: number;
    createdAt: string;
  }[];
  eventos: {
    id: string;
    iglesiaId: string;
    nombre: string;
    fechaEvento: string;
    descripcion: string;
    badge: string;
    publicado: boolean;
    orden: number;
    createdAt: string;
  }[];
  ninos: {
    id: string;
    iglesiaId: string;
    nombre: string;
    tipo: string;
    imagenUrl: string;
    recursoUrl: string;
    publicado: boolean;
    orden: number;
  }[];
  porcarts: {
    id: string;
    iglesiaId: string;
    texto: string;
    referencia: string;
    bgUrl: string;
    activo: boolean;
    orden: number;
  }[];
  galeria: {
    id: string;
    iglesiaId: string;
    imagenUrl: string;
    caption: string;
    publicada: boolean;
    orden: number;
  }[];
  testimonios: {
    id: string;
    iglesiaId: string;
    texto: string;
    autor: string;
    publicado: boolean;
    orden: number;
  }[];
  donaciones: {
    id: string;
    iglesiaId: string;
    activo: boolean;
    urlPago: string;
    mensaje: string;
  } | null;
  oracion: {
    id: string;
    iglesiaId: string;
    activo: boolean;
    whatsapp: string;
    descripcion: string;
  } | null;
  oracionDias: {
    id: string;
    iglesiaId: string;
    dia: string;
    orden: number;
  }[];
  oracionHorarios: {
    id: string;
    iglesiaId: string;
    rangoDias: string;
    hora: string;
    orden: number;
  }[];
}

export interface AuthUser {
  id: string;
  email: string;
  nombre: string;
  rol: string;
}