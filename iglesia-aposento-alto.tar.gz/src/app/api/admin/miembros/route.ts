import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const miembros = await db.miembro.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(miembros);
  } catch (error) {
    console.error('Error fetching miembros:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { nombre, email, telefono, direccion, fechaNacimiento, activo } = body;

    if (!nombre) {
      return NextResponse.json({ error: 'Nombre es requerido' }, { status: 400 });
    }

    const miembro = await db.miembro.create({
      data: {
        iglesiaId: auth.iglesiaId,
        nombre,
        email: email ?? null,
        telefono: telefono ?? null,
        direccion: direccion ?? null,
        fechaNacimiento: fechaNacimiento ? new Date(fechaNacimiento) : null,
        activo: activo ?? true,
      },
    });

    return NextResponse.json(miembro, { status: 201 });
  } catch (error) {
    console.error('Error creating miembro:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, nombre, email, telefono, direccion, fechaNacimiento, activo } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const miembro = await db.miembro.update({
      where: { id },
      data: {
        ...(nombre !== undefined && { nombre }),
        ...(email !== undefined && { email }),
        ...(telefono !== undefined && { telefono }),
        ...(direccion !== undefined && { direccion }),
        ...(fechaNacimiento !== undefined && { fechaNacimiento: fechaNacimiento ? new Date(fechaNacimiento) : null }),
        ...(activo !== undefined && { activo }),
      },
    });

    return NextResponse.json(miembro);
  } catch (error) {
    console.error('Error updating miembro:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.miembro.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting miembro:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}