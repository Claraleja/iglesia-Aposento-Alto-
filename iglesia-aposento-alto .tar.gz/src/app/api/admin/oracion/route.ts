import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { verifyToken } from '@/lib/auth';

function toCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    const camel = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    result[camel] = v;
  }
  return result;
}

async function auth(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    // Fetch oracion config
    const { data: config, error: configErr } = await supabase
      .from('oracion_config')
      .select('*')
      .eq('iglesia_id', a.iglesiaId)
      .limit(1)
      .single();

    // Fetch dias
    const { data: dias, error: diasErr } = await supabase
      .from('oracion_dias')
      .select('*')
      .eq('iglesia_id', a.iglesiaId)
      .order('orden', { ascending: true });

    // Fetch horarios
    const { data: horarios, error: horariosErr } = await supabase
      .from('oracion_horarios')
      .select('*')
      .eq('iglesia_id', a.iglesiaId)
      .order('orden', { ascending: true });

    if (configErr && configErr.code !== 'PGRST116') throw new Error(configErr.message);
    if (diasErr) throw new Error(diasErr.message);
    if (horariosErr) throw new Error(horariosErr.message);

    const configCamel = config ? toCamel(config as Record<string, unknown>) : null;

    return NextResponse.json({
      ...configCamel,
      dias: (dias || []).map((d) => toCamel(d as Record<string, unknown>)),
      horarios: (horarios || []).map((h) => toCamel(h as Record<string, unknown>)),
    });
  } catch (error) {
    console.error('Error fetching oracion config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { dias, horarios, ...configData } = body;
    const iglesiaId = a.iglesiaId;

    // Convert config data to snake_case
    const configRow: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(configData)) {
      const snake = k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());
      configRow[snake] = v;
    }

    // Check if config exists
    const { data: existing } = await supabase
      .from('oracion_config')
      .select('id')
      .eq('iglesia_id', iglesiaId)
      .limit(1)
      .single();

    if (existing) {
      // Update config
      const { error: updateErr } = await supabase
        .from('oracion_config')
        .update(configRow)
        .eq('id', existing.id);
      if (updateErr) throw new Error(updateErr.message);
    } else {
      // Create config
      configRow.iglesia_id = iglesiaId;
      const { error: insertErr } = await supabase
        .from('oracion_config')
        .insert(configRow);
      if (insertErr) throw new Error(insertErr.message);
    }

    // Handle dias replacement
    if (dias !== undefined) {
      // Delete existing dias
      await supabase.from('oracion_dias').delete().eq('iglesia_id', iglesiaId);

      // Insert new dias
      if (Array.isArray(dias) && dias.length > 0) {
        const diasRows = dias.map((d: { dia: string; orden?: number }) => ({
          iglesia_id: iglesiaId,
          dia: d.dia,
          orden: d.orden ?? 0,
        }));
        const { error: diasErr } = await supabase.from('oracion_dias').insert(diasRows);
        if (diasErr) throw new Error(diasErr.message);
      }
    }

    // Handle horarios replacement
    if (horarios !== undefined) {
      // Delete existing horarios
      await supabase.from('oracion_horarios').delete().eq('iglesia_id', iglesiaId);

      // Insert new horarios
      if (Array.isArray(horarios) && horarios.length > 0) {
        const horariosRows = horarios.map((h: { rangoDias: string; hora: string; orden?: number }) => ({
          iglesia_id: iglesiaId,
          rango_dias: h.rangoDias,
          hora: h.hora,
          orden: h.orden ?? 0,
        }));
        const { error: horariosErr } = await supabase.from('oracion_horarios').insert(horariosRows);
        if (horariosErr) throw new Error(horariosErr.message);
      }
    }

    // Fetch updated data to return
    const { data: resultConfig } = await supabase
      .from('oracion_config')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .limit(1)
      .single();

    const { data: resultDias } = await supabase
      .from('oracion_dias')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .order('orden', { ascending: true });

    const { data: resultHorarios } = await supabase
      .from('oracion_horarios')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .order('orden', { ascending: true });

    const resultConfigCamel = resultConfig ? toCamel(resultConfig as Record<string, unknown>) : null;

    return NextResponse.json({
      ...resultConfigCamel,
      dias: (resultDias || []).map((d) => toCamel(d as Record<string, unknown>)),
      horarios: (resultHorarios || []).map((h) => toCamel(h as Record<string, unknown>)),
    });
  } catch (error) {
    console.error('Error updating oracion config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}