-- ========================================
-- Seed para Supabase - Iglesia Aposento Alto
-- Ejecutar en: Supabase Dashboard → SQL Editor
-- ========================================

-- 1. Iglesia principal
INSERT INTO iglesias (id, nombre, slug, letra, logo_url, versiculo, versiculo_ref, mision, created_at, updated_at)
VALUES (
  'igl-001',
  'Iglesia Aposento Alto',
  'aposento-alto',
  'A',
  '',
  'Porque donde dos o tres se reúnen en mi nombre, allí estoy yo en medio de ellos.',
  'Mateo 18:20',
  'Llevar la esperanza del evangelio a toda familia.',
  NOW(), NOW()
) ON CONFLICT (id) DO NOTHING;

-- 2. Contacto
INSERT INTO iglesias_contacto (id, iglesia_id, direccion, telefono, email, whatsapp, facebook_url, instagram_url, youtube_url)
VALUES (
  'cto-001',
  'igl-001',
  'Dirección de la iglesia',
  '+52 55 1234 5678',
  'contacto@aposentoalto.com',
  '525512345678',
  '',
  '',
  ''
) ON CONFLICT DO NOTHING;

-- 3. Hero
INSERT INTO iglesias_hero (id, iglesia_id, imagen_url, footer_slogan, footer_anio)
VALUES (
  'hero-001',
  'igl-001',
  '',
  'Todos son bienvenidos.',
  '2025'
) ON CONFLICT DO NOTHING;

-- 4. Pastor
INSERT INTO pastores (id, iglesia_id, nombre, rol, iniciales, foto_url, bio, orden, activo)
VALUES (
  'pas-001',
  'igl-001',
  'Pastor Nombre',
  'Pastor Principal',
  'PA',
  '',
  'Llamado a predicar el evangelio con poder y unción.',
  1,
  true
) ON CONFLICT DO NOTHING;

-- 5. Horarios
INSERT INTO horarios (id, iglesia_id, dia, servicio, hora, orden, activo) VALUES
  ('hor-001', 'igl-001', 'Domingo', 'Servicio Principal', '10:00 AM', 1, true),
  ('hor-002', 'igl-001', 'Domingo', 'Escuela Bíblica', '9:00 AM', 2, true),
  ('hor-003', 'igl-001', 'Miércoles', 'Estudio Bíblico', '7:00 PM', 3, true),
  ('hor-004', 'igl-001', 'Viernes', 'Noche de Oración', '8:00 PM', 4, true)
ON CONFLICT DO NOTHING;

-- 6. Predicas
INSERT INTO predicas (id, iglesia_id, titulo, serie, predicador, fecha_predica, audio_url, spotify_url, imagen_url, publicada, orden)
VALUES (
  'pre-001', 'igl-001', 'La Fe que Vence al Mundo', 'Serie Fe',
  'Pastor Nombre', '2025-01-12', '', '', '', true, 1
) ON CONFLICT DO NOTHING;

-- 7. Eventos
INSERT INTO eventos (id, iglesia_id, nombre, descripcion, fecha_evento, badge, publicado, orden)
VALUES (
  'evt-001', 'igl-001', 'Conferencia de Avivamiento', 'Un tiempo especial de renewall espiritual.',
  '2025-07-15', 'Especial', true, 1
) ON CONFLICT DO NOTHING;

-- 8. Recursos Niños
INSERT INTO recursos_ninos (id, iglesia_id, nombre, tipo, imagen_url, recurso_url, publicado, orden)
VALUES (
  'nin-001', 'igl-001', 'Lecciones Bíblicas para Niños', 'Libro PDF', '', '#', true, 1
) ON CONFLICT DO NOTHING;

-- 9. Porcarts
INSERT INTO porcarts (id, iglesia_id, texto, referencia, bg_url, activo, orden)
VALUES (
  'por-001', 'igl-001', 'Todo lo puedo en Cristo que me fortalece.', 'Filipenses 4:13', '', true, 1
) ON CONFLICT DO NOTHING;

-- 10. Galería
INSERT INTO galeria (id, iglesia_id, imagen_url, caption, publicada, orden) VALUES
  ('gal-001', 'igl-001', 'https://picsum.photos/seed/church1/800/600', 'Momento de adoración', true, 1),
  ('gal-002', 'igl-001', 'https://picsum.photos/seed/church2/800/600', 'Conferencia juvenil', true, 2),
  ('gal-003', 'igl-001', 'https://picsum.photos/seed/church3/800/600', 'Bautismo', true, 3),
  ('gal-004', 'igl-001', 'https://picsum.photos/seed/church4/800/600', 'Alabanza', true, 4)
ON CONFLICT DO NOTHING;

-- 11. Testimonios
INSERT INTO testimonios (id, iglesia_id, texto, autor, publicado, orden) VALUES
  ('tes-001', 'igl-001', 'Esta iglesia cambió mi vida completamente. Dios es fiel.', 'María García', true, 1),
  ('tes-002', 'igl-001', 'Encontré una familia espiritual aquí. Gracias a Dios por este ministerio.', 'Carlos López', true, 2)
ON CONFLICT DO NOTHING;

-- 12. Donaciones
INSERT INTO donaciones_config (id, iglesia_id, activo, url_pago, mensaje)
VALUES (
  'don-001', 'igl-001', false, '#', 'Tu generosidad hace posible el ministerio.'
) ON CONFLICT DO NOTHING;

-- 13. Oración
INSERT INTO oracion_config (id, iglesia_id, activo, whatsapp, descripcion)
VALUES (
  'ora-001', 'igl-001', false, '525512345678', 'Estamos aquí para orar contigo.'
) ON CONFLICT DO NOTHING;

-- 14. Días de oración
INSERT INTO oracion_dias (id, iglesia_id, dia, orden) VALUES
  ('dia-001', 'igl-001', 'Lunes', 1),
  ('dia-002', 'igl-001', 'Miércoles', 2),
  ('dia-003', 'igl-001', 'Viernes', 3)
ON CONFLICT DO NOTHING;

-- 15. Horarios de oración
INSERT INTO oracion_horarios (id, iglesia_id, rango_dias, hora, orden) VALUES
  ('oh-001', 'igl-001', 'Lunes a Viernes', '6:00 AM - 7:00 AM', 1),
  ('oh-002', 'igl-001', 'Lunes a Viernes', '9:00 PM - 10:00 PM', 2)
ON CONFLICT DO NOTHING;