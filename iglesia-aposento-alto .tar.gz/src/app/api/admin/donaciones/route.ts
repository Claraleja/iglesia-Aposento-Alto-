import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { verifyToken } from '@/lib/auth';

function toCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    const camel = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    result[camel] = v;
  }
  return result;
}

async function auth(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { data, error } = await supabase
      .from('donaciones_config')
      .select('*')
      .eq('iglesia_id', a.iglesiaId)
      .limit(1)
      .single();

    if (error && error.code === 'PGRST116') {
      // No row found
      return NextResponse.json(null);
    }
    if (error) throw new Error(error.message);

    return NextResponse.json(data ? toCamel(data as Record<string, unknown>) : null);
  } catch (error) {
    console.error('Error fetching donaciones config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();

    // Convert camelCase body to snake_case for Supabase
    const row: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(body)) {
      const snake = k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());
      row[snake] = v;
    }

    const { data: existing } = await supabase
      .from('donaciones_config')
      .select('id')
      .eq('iglesia_id', a.iglesiaId)
      .limit(1)
      .single();

    if (existing) {
      const { data, error } = await supabase
        .from('donaciones_config')
        .update(row)
        .eq('id', existing.id)
        .select()
        .single();
      if (error) throw new Error(error.message);
      return NextResponse.json(toCamel(data as Record<string, unknown>));
    } else {
      row.iglesia_id = a.iglesiaId;
      const { data, error } = await supabase
        .from('donaciones_config')
        .insert(row)
        .select()
        .single();
      if (error) throw new Error(error.message);
      return NextResponse.json(toCamel(data as Record<string, unknown>), { status: 201 });
    }
  } catch (error) {
    console.error('Error updating donaciones config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}