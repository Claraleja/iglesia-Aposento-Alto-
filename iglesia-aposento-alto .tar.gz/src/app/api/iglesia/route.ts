import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

const DEFAULTS = {
  iglesia: {
    id: 'default',
    nombre: 'Iglesia Aposento Alto',
    slug: 'aposento-alto',
    letra: 'A',
    logoUrl: '',
    versiculo: 'Porque donde dos o tres se reúnen en mi nombre, allí estoy yo en medio de ellos.',
    versiculoRef: 'Mateo 18:20',
    mision: 'Llevar la esperanza del evangelio a toda familia.',
  },
  contacto: {
    id: 'default',
    iglesia_id: 'default',
    direccion: '',
    telefono: '',
    email: '',
    whatsapp: '525512345678',
    facebook_url: '',
    instagram_url: '',
    youtube_url: '',
  },
  hero: {
    id: 'default',
    iglesia_id: 'default',
    imagen_url: '',
    footer_slogan: 'Todos son bienvenidos.',
    footer_anio: new Date().getFullYear().toString(),
  },
  donaciones: {
    id: 'default',
    iglesia_id: 'default',
    activo: false,
    url_pago: '#',
    mensaje: 'Tu generosidad hace posible el ministerio.',
  },
  oracion: {
    id: 'default',
    iglesia_id: 'default',
    activo: false,
    whatsapp: '',
    descripcion: 'Estamos aquí para orar contigo.',
  },
};

function snakeToCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    const camelKey = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    result[camelKey] = value;
  }
  return result;
}

function mapRow(row: Record<string, unknown>): Record<string, unknown> {
  const mapped = snakeToCamel(row);
  // Convert date strings
  for (const [key, value] of Object.entries(mapped)) {
    if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}/)) {
      try { mapped[key] = new Date(value + 'T12:00:00').toISOString(); } catch { /* keep string */ }
    }
  }
  return mapped;
}

function mapRows(rows: Record<string, unknown>[]): Record<string, unknown>[] {
  return rows.map(mapRow);
}

export async function GET() {
  try {
    const { data: iglesia } = await supabase.from('iglesias').select('*').limit(1).single();
    const church = iglesia ? mapRow(iglesia) : DEFAULTS.iglesia;
    const iglesiaId = church.id as string;

    const [contactoRes, heroRes, donacionesRes, oracionRes, pastoresRes, horariosRes, predicasRes, eventosRes, ninosRes, porcartsRes, galeriaRes, testimoniosRes, oracionDiasRes, oracionHorariosRes] = await Promise.all([
      supabase.from('iglesias_contacto').select('*').eq('iglesia_id', iglesiaId).limit(1).single(),
      supabase.from('iglesias_hero').select('*').eq('iglesia_id', iglesiaId).limit(1).single(),
      supabase.from('donaciones_config').select('*').eq('iglesia_id', iglesiaId).limit(1).single(),
      supabase.from('oracion_config').select('*').eq('iglesia_id', iglesiaId).limit(1).single(),
      supabase.from('pastores').select('*').eq('iglesia_id', iglesiaId).eq('activo', true).order('orden'),
      supabase.from('horarios').select('*').eq('iglesia_id', iglesiaId).eq('activo', true).order('orden'),
      supabase.from('predicas').select('*').eq('iglesia_id', iglesiaId).eq('publicada', true).order('orden'),
      supabase.from('eventos').select('*').eq('iglesia_id', iglesiaId).eq('publicado', true).order('fecha_evento', { ascending: false }),
      supabase.from('recursos_ninos').select('*').eq('iglesia_id', iglesiaId).eq('publicado', true).order('orden'),
      supabase.from('porcarts').select('*').eq('iglesia_id', iglesiaId).eq('activo', true).order('orden'),
      supabase.from('galeria').select('*').eq('iglesia_id', iglesiaId).eq('publicada', true).order('orden'),
      supabase.from('testimonios').select('*').eq('iglesia_id', iglesiaId).eq('publicado', true).order('orden'),
      supabase.from('oracion_dias').select('*').eq('iglesia_id', iglesiaId).order('orden'),
      supabase.from('oracion_horarios').select('*').eq('iglesia_id', iglesiaId).order('orden'),
    ]);

    return NextResponse.json({
      iglesia: church,
      contacto: contactoRes.data ? mapRow(contactoRes.data) : DEFAULTS.contacto,
      hero: heroRes.data ? mapRow(heroRes.data) : DEFAULTS.hero,
      pastor: pastoresRes.data?.[0] ? mapRow(pastoresRes.data[0]) : null,
      horarios: mapRows(horariosRes.data || []),
      predicas: mapRows(predicasRes.data || []),
      eventos: mapRows(eventosRes.data || []),
      ninos: mapRows(ninosRes.data || []),
      porcarts: mapRows(porcartsRes.data || []),
      galeria: mapRows(galeriaRes.data || []),
      testimonios: mapRows(testimoniosRes.data || []),
      donaciones: donacionesRes.data ? mapRow(donacionesRes.data) : DEFAULTS.donaciones,
      oracion: oracionRes.data ? mapRow(oracionRes.data) : DEFAULTS.oracion,
      oracionDias: mapRows(oracionDiasRes.data || []),
      oracionHorarios: mapRows(oracionHorariosRes.data || []),
    });
  } catch (error) {
    console.error('Error fetching iglesia data:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}