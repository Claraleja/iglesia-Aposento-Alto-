import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const ninos = await db.recursoNino.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(ninos);
  } catch (error) {
    console.error('Error fetching recursos niños:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { nombre, tipo, imagenUrl, recursoUrl, publicado, orden } = body;

    if (!nombre) {
      return NextResponse.json({ error: 'Nombre es requerido' }, { status: 400 });
    }

    const recurso = await db.recursoNino.create({
      data: {
        iglesiaId: auth.iglesiaId,
        nombre,
        tipo: tipo ?? 'Libro PDF',
        imagenUrl: imagenUrl ?? '',
        recursoUrl: recursoUrl ?? '#',
        publicado: publicado ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(recurso, { status: 201 });
  } catch (error) {
    console.error('Error creating recurso niño:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, nombre, tipo, imagenUrl, recursoUrl, publicado, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const recurso = await db.recursoNino.update({
      where: { id },
      data: {
        ...(nombre !== undefined && { nombre }),
        ...(tipo !== undefined && { tipo }),
        ...(imagenUrl !== undefined && { imagenUrl }),
        ...(recursoUrl !== undefined && { recursoUrl }),
        ...(publicado !== undefined && { publicado }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(recurso);
  } catch (error) {
    console.error('Error updating recurso niño:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.recursoNino.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting recurso niño:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
