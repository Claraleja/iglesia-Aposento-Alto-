import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { verifyToken } from '@/lib/auth';

function toCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    const camel = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    result[camel] = v;
  }
  return result;
}

async function auth(request: NextRequest) {
  return verifyToken(request);
}

function toSnake(body: Record<string, unknown>): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(body)) {
    const snake = k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());
    row[snake] = v;
  }
  return row;
}

// GET: Fetch iglesia config + contacto + hero + pastor
export async function GET(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const iglesiaId = a.iglesiaId;

    // Fetch main iglesia
    const { data: iglesia, error: iglesiaErr } = await supabase
      .from('iglesias')
      .select('*')
      .eq('id', iglesiaId)
      .single();
    if (iglesiaErr) throw new Error(iglesiaErr.message);
    if (!iglesia) return NextResponse.json({ error: 'Iglesia no encontrada' }, { status: 404 });

    // Fetch contacto
    const { data: contacto } = await supabase
      .from('iglesias_contacto')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .limit(1)
      .single();

    // Fetch hero
    const { data: hero } = await supabase
      .from('iglesias_hero')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .limit(1)
      .single();

    // Fetch active pastores
    const { data: pastores } = await supabase
      .from('pastores')
      .select('*')
      .eq('iglesia_id', iglesiaId)
      .eq('activo', true);

    return NextResponse.json({
      ...toCamel(iglesia as Record<string, unknown>),
      contacto: contacto ? toCamel(contacto as Record<string, unknown>) : null,
      hero: hero ? toCamel(hero as Record<string, unknown>) : null,
      pastor: pastores && pastores.length > 0 ? toCamel(pastores[0] as Record<string, unknown>) : null,
    });
  } catch (error) {
    console.error('Error fetching iglesia config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

// PUT: Update iglesia main config, contact, hero, or pastor based on `section` query param
export async function PUT(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const section = searchParams.get('section') || 'main';
    const body = await request.json();
    const iglesiaId = a.iglesiaId;

    if (section === 'main') {
      const { nombre, letra, versiculo, versiculoRef, mision, logoUrl } = body;
      const updates: Record<string, unknown> = {};
      if (nombre !== undefined) updates.nombre = nombre;
      if (letra !== undefined) updates.letra = letra;
      if (versiculo !== undefined) updates.versiculo = versiculo;
      if (versiculoRef !== undefined) updates.versiculo_ref = versiculoRef;
      if (mision !== undefined) updates.mision = mision;
      if (logoUrl !== undefined) updates.logo_url = logoUrl;

      const { data, error } = await supabase
        .from('iglesias')
        .update(updates)
        .eq('id', iglesiaId)
        .select()
        .single();
      if (error) throw new Error(error.message);
      return NextResponse.json(toCamel(data as Record<string, unknown>));
    }

    if (section === 'contacto') {
      const { data: existing } = await supabase
        .from('iglesias_contacto')
        .select('id')
        .eq('iglesia_id', iglesiaId)
        .limit(1)
        .single();

      const row: Record<string, unknown> = toSnake(body);
      if (existing) {
        const { data, error } = await supabase
          .from('iglesias_contacto')
          .update(row)
          .eq('id', existing.id)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>));
      } else {
        row.iglesia_id = iglesiaId;
        const { data, error } = await supabase
          .from('iglesias_contacto')
          .insert(row)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>), { status: 201 });
      }
    }

    if (section === 'hero') {
      const { data: existing } = await supabase
        .from('iglesias_hero')
        .select('id')
        .eq('iglesia_id', iglesiaId)
        .limit(1)
        .single();

      const row: Record<string, unknown> = toSnake(body);
      if (existing) {
        const { data, error } = await supabase
          .from('iglesias_hero')
          .update(row)
          .eq('id', existing.id)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>));
      } else {
        row.iglesia_id = iglesiaId;
        const { data, error } = await supabase
          .from('iglesias_hero')
          .insert(row)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>), { status: 201 });
      }
    }

    if (section === 'pastor') {
      const { data: existing } = await supabase
        .from('pastores')
        .select('id')
        .eq('iglesia_id', iglesiaId)
        .limit(1)
        .single();

      const row: Record<string, unknown> = toSnake(body);
      if (existing) {
        const { data, error } = await supabase
          .from('pastores')
          .update(row)
          .eq('id', existing.id)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>));
      } else {
        row.iglesia_id = iglesiaId;
        const { data, error } = await supabase
          .from('pastores')
          .insert(row)
          .select()
          .single();
        if (error) throw new Error(error.message);
        return NextResponse.json(toCamel(data as Record<string, unknown>), { status: 201 });
      }
    }

    return NextResponse.json({ error: 'Sección no válida' }, { status: 400 });
  } catch (error) {
    console.error('Error updating iglesia config:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}