import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nombre, email, telefono, mensaje } = body;

    if (!nombre || !email || !mensaje) {
      return NextResponse.json(
        { error: 'Nombre, email y mensaje son requeridos' },
        { status: 400 }
      );
    }

    const iglesia = await db.iglesia.findFirst();
    if (!iglesia) {
      return NextResponse.json({ error: 'Iglesia no configurada' }, { status: 400 });
    }

    const nuevoMensaje = await db.mensajeContacto.create({
      data: {
        iglesiaId: iglesia.id,
        nombre,
        email,
        telefono: telefono || '',
        mensaje,
      },
    });

    return NextResponse.json({ success: true, mensaje: nuevoMensaje }, { status: 201 });
  } catch (error) {
    console.error('Error al enviar mensaje:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}