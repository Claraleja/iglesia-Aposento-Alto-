import { NextResponse } from 'next/server';

export async function POST() {
  return NextResponse.json({ success: true, message: 'Usa WhatsApp para contactar' });
}

export async function GET() {
  return NextResponse.json({ success: true, message: 'Usa WhatsApp para contactar' });
}