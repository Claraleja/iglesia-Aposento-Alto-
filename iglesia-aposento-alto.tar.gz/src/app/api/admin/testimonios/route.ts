import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const testimonios = await db.testimonio.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(testimonios);
  } catch (error) {
    console.error('Error fetching testimonios:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { texto, autor, publicado, orden } = body;

    if (!texto || !autor) {
      return NextResponse.json({ error: 'Texto y autor son requeridos' }, { status: 400 });
    }

    const testimonio = await db.testimonio.create({
      data: {
        iglesiaId: auth.iglesiaId,
        texto,
        autor,
        publicado: publicado ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(testimonio, { status: 201 });
  } catch (error) {
    console.error('Error creating testimonio:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, texto, autor, publicado, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const testimonio = await db.testimonio.update({
      where: { id },
      data: {
        ...(texto !== undefined && { texto }),
        ...(autor !== undefined && { autor }),
        ...(publicado !== undefined && { publicado }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(testimonio);
  } catch (error) {
    console.error('Error updating testimonio:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.testimonio.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting testimonio:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
