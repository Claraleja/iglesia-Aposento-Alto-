import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const IGLESIA_ID = "iglesia-aposento-alto-001";

async function main() {
  console.log("🌱 Seeding database...");

  // ── Iglesia ──
  const iglesia = await prisma.iglesia.upsert({
    where: { id: IGLESIA_ID },
    update: {},
    create: {
      id: IGLESIA_ID,
      nombre: "Iglesia Aposento Alto",
      slug: "aposento-alto",
      letra: "A",
      logoUrl: "/logo-placeholder.png",
      versiculo:
        "Porque donde dos o tres se reúnen en mi nombre, allí estoy yo en medio de ellos.",
      versiculoRef: "Mateo 18:20",
      mision: "Llevar la esperanza del evangelio a toda familia.",
    },
  });
  console.log(`✅ Iglesia creada: ${iglesia.nombre}`);

  // ── IglesiaContacto ──
  await prisma.iglesiaContacto.upsert({
    where: { iglesiaId: IGLESIA_ID },
    update: {},
    create: {
      iglesiaId: IGLESIA_ID,
      direccion: "Av. Central #456, Col. Centro, Ciudad de México, CP 06000",
      telefono: "+52 55 1234 5678",
      email: "info@aposentoalto.com",
      whatsapp: "525512345678",
      facebookUrl: "https://facebook.com/aposentoalto",
      instagramUrl: "https://instagram.com/aposentoalto",
      youtubeUrl: "https://youtube.com/@aposentoalto",
    },
  });
  console.log("✅ IglesiaContacto creado");

  // ── IglesiaHero ──
  await prisma.iglesiaHero.upsert({
    where: { iglesiaId: IGLESIA_ID },
    update: {},
    create: {
      iglesiaId: IGLESIA_ID,
      imagenUrl:
        "/hero-matrimonio.png",
      footerSlogan: "Todos son bienvenidos en la casa del Señor.",
      footerAnio: "2025",
    },
  });
  console.log("✅ IglesiaHero creado");

  // ── Pastor ──
  await prisma.pastor.create({
    data: {
      iglesiaId: IGLESIA_ID,
      nombre: "Pastor Carlos Mendoza",
      rol: "Pastor Principal",
      iniciales: "CM",
      fotoUrl: "https://picsum.photos/seed/pastor-carlos/400/400",
      bio: "Pastor Carlos Mendoza ha servido al Señor por más de 20 años. Fundó Iglesia Aposento Alto con la visión de alcanzar a las familias con el amor de Cristo. Está casado con María y tienen tres hijos. Su pasión es la enseñanza de la Palabra y el discipulado.",
      orden: 1,
      activo: true,
    },
  });
  console.log("✅ Pastor creado");

  // ── Horarios ──
  const horarios = [
    { dia: "Domingo", servicio: "Servicio Principal", hora: "10:00 AM", orden: 1 },
    { dia: "Domingo", servicio: "Escuela Bíblica", hora: "8:30 AM", orden: 2 },
    { dia: "Domingo", servicio: "Servicio de Juventud", hora: "6:00 PM", orden: 3 },
    { dia: "Miércoles", servicio: "Estudio Bíblico", hora: "7:00 PM", orden: 4 },
    { dia: "Viernes", servicio: "Noche de Oración", hora: "8:00 PM", orden: 5 },
    { dia: "Sábado", servicio: "Ensayo de Alabanza", hora: "4:00 PM", orden: 6 },
  ];
  await prisma.horario.createMany({
    data: horarios.map((h) => ({ ...h, iglesiaId: IGLESIA_ID, activo: true })),
  });
  console.log(`✅ ${horarios.length} Horarios creados`);

  // ── Predicas ──
  const predicas = [
    {
      titulo: "El propósito de la fe",
      serie: "Fundamentos",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-01-12",
      audioUrl: "https://example.com/audio/proposito-fe.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder1",
      imagenUrl: "https://picsum.photos/seed/predica1/600/400",
      orden: 1,
    },
    {
      titulo: "Andando en el Espíritu",
      serie: "Fundamentos",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-01-19",
      audioUrl: "https://example.com/audio/andando-espiritu.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder2",
      imagenUrl: "https://picsum.photos/seed/predica2/600/400",
      orden: 2,
    },
    {
      titulo: "La armadura de Dios",
      serie: "Guerra Espiritual",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-02-02",
      audioUrl: "https://example.com/audio/armadura-dios.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder3",
      imagenUrl: "https://picsum.photos/seed/predica3/600/400",
      orden: 3,
    },
    {
      titulo: "Gracia que transforma",
      serie: "Gracia",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-02-16",
      audioUrl: "https://example.com/audio/gracia-transforma.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder4",
      imagenUrl: "https://picsum.photos/seed/predica4/600/400",
      orden: 4,
    },
    {
      titulo: "Oración eficaz",
      serie: "Guerra Espiritual",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-03-01",
      audioUrl: "https://example.com/audio/oracion-eficaz.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder5",
      imagenUrl: "https://picsum.photos/seed/predica5/600/400",
      orden: 5,
    },
    {
      titulo: "El poder de la comunión",
      serie: "Comunidad",
      predicador: "Pastor Carlos Mendoza",
      fechaPredica: "2025-03-15",
      audioUrl: "https://example.com/audio/poder-comunion.mp3",
      spotifyUrl: "https://open.spotify.com/episode/placeholder6",
      imagenUrl: "https://picsum.photos/seed/predica6/600/400",
      orden: 6,
    },
  ];
  await prisma.predica.createMany({
    data: predicas.map((p) => ({ ...p, iglesiaId: IGLESIA_ID, publicada: true })),
  });
  console.log(`✅ ${predicas.length} Predicas creadas`);

  // ── Eventos ──
  const eventos = [
    {
      nombre: "Retiro de Verano 2025",
      fechaEvento: "2025-07-18",
      descripcion:
        "Tres días de refrigerio espiritual, alabanza y comunión en la naturaleza. Habrá actividades para toda la familia, estudios bíblicos y momentos de adoración.",
      badge: "Retiro",
      orden: 1,
    },
    {
      nombre: "Conferencia de Mujeres",
      fechaEvento: "2025-08-09",
      descripcion:
        "Un evento especial para mujeres de todas las edades. Tema: 'Mujer valiosa en el reino'. Habrá speakers invitadas, alabanza y ministerio personal.",
      badge: "Conferencia",
      orden: 2,
    },
    {
      nombre: "Bautismos",
      fechaEvento: "2025-06-22",
      descripcion:
        "Ceremonia de bautismo en agua para quienes desean dar este paso de fe. Requisito: clase preparatoria previa.",
      badge: "Bautismo",
      orden: 3,
    },
    {
      nombre: "Campaña Evangelística",
      fechaEvento: "2025-09-13",
      descripcion:
        "Jornada de alcance comunitario con música en vivo, dramatizaciones y la predicación del evangelio. Invita a tus familiares y amigos.",
      badge: "Evangelismo",
      orden: 4,
    },
  ];
  await prisma.evento.createMany({
    data: eventos.map((e) => ({ ...e, iglesiaId: IGLESIA_ID, publicado: true })),
  });
  console.log(`✅ ${eventos.length} Eventos creados`);

  // ── RecursoNino ──
  const recursosNinos = [
    {
      nombre: "Historias de la Biblia para Colorear",
      tipo: "Libro PDF",
      imagenUrl: "https://picsum.photos/seed/ninos1/400/300",
      recursoUrl: "#",
      orden: 1,
    },
    {
      nombre: "Devocional Infantil Semanal",
      tipo: "PDF Descargable",
      imagenUrl: "https://picsum.photos/seed/ninos2/400/300",
      recursoUrl: "#",
      orden: 2,
    },
    {
      nombre: "Manual de Alabanza para Niños",
      tipo: "Libro PDF",
      imagenUrl: "https://picsum.photos/seed/ninos3/400/300",
      recursoUrl: "#",
      orden: 3,
    },
    {
      nombre: "Actividades del Domingo",
      tipo: "Hoja de Actividades",
      imagenUrl: "https://picsum.photos/seed/ninos4/400/300",
      recursoUrl: "#",
      orden: 4,
    },
  ];
  await prisma.recursoNino.createMany({
    data: recursosNinos.map((r) => ({ ...r, iglesiaId: IGLESIA_ID, publicado: true })),
  });
  console.log(`✅ ${recursosNinos.length} RecursoNino creados`);

  // ── Porcarts ──
  const porcarts = [
    {
      texto: "Confía en el Señor con todo tu corazón, y no te apoyes en tu propia prudencia.",
      referencia: "Proverbios 3:5",
      bgUrl: "https://picsum.photos/seed/porcart1/800/600",
      orden: 1,
    },
    {
      texto: "Todo lo puedo en Cristo que me fortalece.",
      referencia: "Filipenses 4:13",
      bgUrl: "https://picsum.photos/seed/porcart2/800/600",
      orden: 2,
    },
    {
      texto: "Porque yo sé los planes que tengo para ustedes, planes de bienestar y no de calamidad.",
      referencia: "Jeremías 29:11",
      bgUrl: "https://picsum.photos/seed/porcart3/800/600",
      orden: 3,
    },
    {
      texto: "El Señor es mi pastor, nada me faltará.",
      referencia: "Salmo 23:1",
      bgUrl: "https://picsum.photos/seed/porcart4/800/600",
      orden: 4,
    },
    {
      texto: "No temas, porque yo estoy contigo; no desmayes, porque yo soy tu Dios.",
      referencia: "Isaías 41:10",
      bgUrl: "https://picsum.photos/seed/porcart5/800/600",
      orden: 5,
    },
    {
      texto: "Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito.",
      referencia: "Juan 3:16",
      bgUrl: "https://picsum.photos/seed/porcart6/800/600",
      orden: 6,
    },
  ];
  await prisma.porcart.createMany({
    data: porcarts.map((p) => ({ ...p, iglesiaId: IGLESIA_ID, activo: true })),
  });
  console.log(`✅ ${porcarts.length} Porcarts creados`);

  // ── GaleriaItem ──
  const galeria = [
    { imagenUrl: "https://picsum.photos/seed/church1/800/600", caption: "Servicio dominical de alabanza", orden: 1 },
    { imagenUrl: "https://picsum.photos/seed/church2/800/600", caption: "Bautismos de verano 2024", orden: 2 },
    { imagenUrl: "https://picsum.photos/seed/church3/800/600", caption: "Retiro de jóvenes en la montaña", orden: 3 },
    { imagenUrl: "https://picsum.photos/seed/church4/800/600", caption: "Conferencia de mujeres", orden: 4 },
    { imagenUrl: "https://picsum.photos/seed/church5/800/600", caption: "Ministerio de niños en acción", orden: 5 },
    { imagenUrl: "https://picsum.photos/seed/church6/800/600", caption: "Noche de oración y ayuno", orden: 6 },
    { imagenUrl: "https://picsum.photos/seed/church7/800/600", caption: "Cena de la amistad comunitaria", orden: 7 },
    { imagenUrl: "https://picsum.photos/seed/church8/800/600", caption: "Evangelismo en la plaza central", orden: 8 },
  ];
  await prisma.galeriaItem.createMany({
    data: galeria.map((g) => ({ ...g, iglesiaId: IGLESIA_ID, publicada: true })),
  });
  console.log(`✅ ${galeria.length} GaleriaItems creados`);

  // ── Testimonios ──
  const testimonios = [
    {
      texto: "Llegué a la iglesia en un momento muy difícil de mi vida. El amor y la acogida que recibí me ayudaron a encontrarme con Dios. Hoy mi familia entera sirve al Señor.",
      autor: "María García",
      orden: 1,
    },
    {
      texto: "El ministerio de jóvenes cambió la vida de mi hijo. Ahora es un líder en la iglesia y su pasión por Dios es un testimonio vivo para todos nosotros.",
      autor: "Roberto Hernández",
      orden: 2,
    },
    {
      texto: "A través de los estudios bíblicos del miércoles, he crecido enormemente en mi fe. La enseñanza es clara, bíblica y aplicable a la vida diaria.",
      autor: "Ana Martínez",
      orden: 3,
    },
    {
      texto: "Después de años lejos de Dios, regresé a la iglesia y encontré una comunidad que me recibió con los brazos abiertos. Mi vida tiene un propósito nuevo.",
      autor: "Jorge López",
      orden: 4,
    },
  ];
  await prisma.testimonio.createMany({
    data: testimonios.map((t) => ({ ...t, iglesiaId: IGLESIA_ID, publicado: true })),
  });
  console.log(`✅ ${testimonios.length} Testimonios creados`);

  // ── DonacionConfig ──
  await prisma.donacionConfig.upsert({
    where: { iglesiaId: IGLESIA_ID },
    update: {},
    create: {
      iglesiaId: IGLESIA_ID,
      activo: true,
      urlPago: "https://example.com/donar/aposento-alto",
      mensaje: "Tu generosidad hace posible el ministerio. Cada donación es una semilla de bendición.",
    },
  });
  console.log("✅ DonacionConfig creado");

  // ── OracionConfig ──
  await prisma.oracionConfig.upsert({
    where: { iglesiaId: IGLESIA_ID },
    update: {},
    create: {
      iglesiaId: IGLESIA_ID,
      activo: true,
      whatsapp: "525512345678",
      descripcion: "Estamos aquí para orar contigo. Envíanos tu petición y nuestro equipo de intercesión estará orando por ti.",
    },
  });
  console.log("✅ OracionConfig creado");

  // ── OracionDias ──
  const oracionDias = [
    { dia: "Lunes", orden: 1 },
    { dia: "Martes", orden: 2 },
    { dia: "Miércoles", orden: 3 },
    { dia: "Jueves", orden: 4 },
  ];
  await prisma.oracionDia.createMany({
    data: oracionDias.map((d) => ({ ...d, iglesiaId: IGLESIA_ID })),
  });
  console.log(`✅ ${oracionDias.length} OracionDias creados`);

  // ── OracionHorarios ──
  const oracionHorarios = [
    { rangoDias: "Lunes a Jueves", hora: "6:00 AM - 7:00 AM", orden: 1 },
    { rangoDias: "Lunes a Jueves", hora: "9:00 PM - 10:00 PM", orden: 2 },
    { rangoDias: "Viernes", hora: "8:00 PM - 10:00 PM", orden: 3 },
  ];
  await prisma.oracionHorario.createMany({
    data: oracionHorarios.map((h) => ({ ...h, iglesiaId: IGLESIA_ID })),
  });
  console.log(`✅ ${oracionHorarios.length} OracionHorarios creados`);

  // ── Usuario (admin) ──
  const passwordHash = await bcrypt.hash("admin123", 10);
  await prisma.usuario.upsert({
    where: { email: "admin@iglesia.com" },
    update: {},
    create: {
      iglesiaId: IGLESIA_ID,
      email: "admin@iglesia.com",
      password: passwordHash,
      nombre: "Administrador",
      rol: "admin",
      activo: true,
    },
  });
  console.log("✅ Usuario admin creado (admin@iglesia.com / admin123)");

  // ── Miembros ──
  const miembros = [
    {
      nombre: "María",
      apellido: "García López",
      email: "maria.garcia@email.com",
      telefono: "+52 55 1111 2222",
      fechaNacimiento: "1985-04-15",
      direccion: "Col. Roma Norte, CDMX",
      ministerio: "Alabanza",
      activo: true,
    },
    {
      nombre: "Roberto",
      apellido: "Hernández Pérez",
      email: "roberto.h@email.com",
      telefono: "+52 55 2222 3333",
      fechaNacimiento: "1978-09-22",
      direccion: "Col. Del Valle, CDMX",
      ministerio: "Diaconía",
      activo: true,
    },
    {
      nombre: "Ana",
      apellido: "Martínez Ruiz",
      email: "ana.martinez@email.com",
      telefono: "+52 55 3333 4444",
      fechaNacimiento: "1990-12-03",
      direccion: "Col. Polanco, CDMX",
      ministerio: "Enseñanza",
      activo: true,
    },
    {
      nombre: "Jorge",
      apellido: "López Sánchez",
      email: "jorge.lopez@email.com",
      telefono: "+52 55 4444 5555",
      fechaNacimiento: "1982-06-18",
      direccion: "Col. Coyoacán, CDMX",
      ministerio: "Evangelismo",
      activo: true,
    },
    {
      nombre: "Carmen",
      apellido: "Díaz Torres",
      email: "carmen.diaz@email.com",
      telefono: "+52 55 5555 6666",
      fechaNacimiento: "1995-01-30",
      direccion: "Col. Narvarte, CDMX",
      ministerio: "Niños",
      activo: true,
    },
  ];
  await prisma.miembro.createMany({
    data: miembros.map((m) => ({ ...m, iglesiaId: IGLESIA_ID })),
  });
  console.log(`✅ ${miembros.length} Miembros creados`);

  // ── MensajeContacto ──
  const mensajes = [
    {
      nombre: "Laura Fernández",
      email: "laura.f@email.com",
      telefono: "+52 55 6666 7777",
      mensaje:
        "Hola, me gustaría saber más sobre los servicios del domingo y si hay actividades para niños. Mi familia está buscando una iglesia.",
      leido: false,
    },
    {
      nombre: "Pedro Ramírez",
      email: "pedro.r@email.com",
      telefono: "",
      mensaje:
        "Quisiera información sobre cómo unirme al grupo de jóvenes. Tengo 19 años y recién me mude a la ciudad.",
      leido: true,
    },
    {
      nombre: "Isabel Cruz",
      email: "isabel.cruz@email.com",
      telefono: "+52 55 8888 9999",
      mensaje:
        "Necesito habla con un pastor. Estoy pasando por una situación difícil y quiero orientación espiritual. Gracias.",
      leido: false,
    },
  ];
  await prisma.mensajeContacto.createMany({
    data: mensajes.map((m) => ({ ...m, iglesiaId: IGLESIA_ID })),
  });
  console.log(`✅ ${mensajes.length} MensajeContacto creados`);

  // ── CitaOracion (citas_oracion) ──
  const citas = [
    {
      nombre: "Carmen Rojas",
      telefono: "+52 55 7777 8888",
      peticion: "Oren por la salud de mi madre que está enferma. Necesitamos un milagro de Dios.",
      leido: false,
    },
    {
      nombre: "Miguel Torres",
      telefono: "+52 55 9999 0000",
      peticion: "Estoy buscando empleo hace meses. Pido oración por provisión económica para mi familia.",
      leido: true,
    },
  ];
  await prisma.citaOracion.createMany({
    data: citas.map((c) => ({ ...c, iglesiaId: IGLESIA_ID })),
  });
  console.log(`✅ ${citas.length} CitaOracion creadas`);

  console.log("\n🎉 Seeding completado exitosamente!");
}

main()
  .catch((e) => {
    console.error("❌ Error en seeding:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });