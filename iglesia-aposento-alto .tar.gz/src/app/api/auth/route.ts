import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const JWT_SECRET = process.env.JWT_SECRET || 'iglesia-default-secret';
const ADMIN_EMAIL = 'admin@iglesia.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: 'Email y contraseña son requeridos' },
        { status: 400 }
      );
    }

    // Try to find user in usuarios table first
    const { data: usuario } = await supabase
      .from('usuarios')
      .select('*')
      .eq('email', email)
      .eq('activo', true)
      .single();

    if (usuario) {
      const isValid = await bcrypt.compare(password, usuario.password);
      if (!isValid) {
        return NextResponse.json({ success: false, error: 'Credenciales inválidas' }, { status: 401 });
      }

      const token = jwt.sign(
        { userId: usuario.id, email: usuario.email, role: usuario.rol, iglesiaId: usuario.iglesia_id },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      return NextResponse.json({ success: true, token, user: { id: usuario.id, email: usuario.email, nombre: usuario.nombre, rol: usuario.rol } });
    }

    // Fallback: check against env ADMIN_PASSWORD
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      // Find or get the first iglesia
      const { data: iglesia } = await supabase.from('iglesias').select('id').limit(1).single();
      const iglesiaId = iglesia?.id || 'default';

      const token = jwt.sign(
        { userId: 'admin', email: ADMIN_EMAIL, role: 'admin', iglesiaId },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      return NextResponse.json({
        success: true,
        token,
        user: { id: 'admin', email: ADMIN_EMAIL, nombre: 'Administrador', rol: 'admin' },
      });
    }

    return NextResponse.json({ success: false, error: 'Credenciales inválidas' }, { status: 401 });
  } catch (error) {
    console.error('Error en login:', error);
    return NextResponse.json({ success: false, error: 'Error interno del servidor' }, { status: 500 });
  }
}