import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const galeria = await db.galeriaItem.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(galeria);
  } catch (error) {
    console.error('Error fetching galeria:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { imagenUrl, caption, publicada, orden } = body;

    if (!imagenUrl) {
      return NextResponse.json({ error: 'URL de imagen es requerida' }, { status: 400 });
    }

    const item = await db.galeriaItem.create({
      data: {
        iglesiaId: auth.iglesiaId,
        imagenUrl,
        caption: caption ?? '',
        publicada: publicada ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error('Error creating galeria item:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, imagenUrl, caption, publicada, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const item = await db.galeriaItem.update({
      where: { id },
      data: {
        ...(imagenUrl !== undefined && { imagenUrl }),
        ...(caption !== undefined && { caption }),
        ...(publicada !== undefined && { publicada }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(item);
  } catch (error) {
    console.error('Error updating galeria item:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.galeriaItem.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting galeria item:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
