import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { verifyToken } from '@/lib/auth';

function toCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    const camel = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    result[camel] = v;
  }
  return result;
}

async function auth(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { data, error } = await supabase
      .from('horarios')
      .select('*')
      .eq('iglesia_id', a.iglesiaId)
      .order('orden', { ascending: true });
    if (error) throw new Error(error.message);
    return NextResponse.json((data || []).map((d) => toCamel(d as Record<string, unknown>)));
  } catch (error) {
    console.error('Error fetching horarios:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { dia, hora } = body;

    if (!dia || !hora) {
      return NextResponse.json({ error: 'Día y hora son requeridos' }, { status: 400 });
    }

    const row: Record<string, unknown> = {
      iglesia_id: a.iglesiaId,
      dia,
      hora,
      servicio: body.servicio ?? null,
      activo: body.activo ?? true,
      orden: body.orden ?? 0,
    };

    const { data, error } = await supabase
      .from('horarios')
      .insert(row)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return NextResponse.json(toCamel(data as Record<string, unknown>), { status: 201 });
  } catch (error) {
    console.error('Error creating horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, ...fields } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const updates: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(fields)) {
      const snake = k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());
      updates[snake] = v;
    }

    const { data, error } = await supabase
      .from('horarios')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return NextResponse.json(toCamel(data as Record<string, unknown>));
  } catch (error) {
    console.error('Error updating horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const a = await auth(request);
  if (!a) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const { error } = await supabase.from('horarios').delete().eq('id', id);
    if (error) throw new Error(error.message);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting horario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}