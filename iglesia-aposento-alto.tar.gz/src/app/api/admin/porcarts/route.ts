import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const porcarts = await db.porcart.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { orden: 'asc' },
    });
    return NextResponse.json(porcarts);
  } catch (error) {
    console.error('Error fetching porcarts:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { texto, referencia, bgUrl, activo, orden } = body;

    if (!texto) {
      return NextResponse.json({ error: 'Texto es requerido' }, { status: 400 });
    }

    const porcart = await db.porcart.create({
      data: {
        iglesiaId: auth.iglesiaId,
        texto,
        referencia: referencia ?? '',
        bgUrl: bgUrl ?? '',
        activo: activo ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(porcart, { status: 201 });
  } catch (error) {
    console.error('Error creating porcart:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, texto, referencia, bgUrl, activo, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const porcart = await db.porcart.update({
      where: { id },
      data: {
        ...(texto !== undefined && { texto }),
        ...(referencia !== undefined && { referencia }),
        ...(bgUrl !== undefined && { bgUrl }),
        ...(activo !== undefined && { activo }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(porcart);
  } catch (error) {
    console.error('Error updating porcart:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.porcart.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting porcart:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
