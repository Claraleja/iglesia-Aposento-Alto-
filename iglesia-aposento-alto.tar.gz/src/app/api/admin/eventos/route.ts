import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

async function authenticate(request: NextRequest) {
  return verifyToken(request);
}

export async function GET(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const eventos = await db.evento.findMany({
      where: { iglesiaId: auth.iglesiaId },
      orderBy: { fechaEvento: 'desc' },
    });
    return NextResponse.json(eventos);
  } catch (error) {
    console.error('Error fetching eventos:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { nombre, descripcion, fechaEvento, badge, publicado, orden } = body;

    if (!nombre) {
      return NextResponse.json({ error: 'Nombre es requerido' }, { status: 400 });
    }

    const evento = await db.evento.create({
      data: {
        iglesiaId: auth.iglesiaId,
        nombre,
        descripcion: descripcion ?? '',
        fechaEvento: fechaEvento ?? '',
        badge: badge ?? 'Evento',
        publicado: publicado ?? true,
        orden: orden ?? 0,
      },
    });

    return NextResponse.json(evento, { status: 201 });
  } catch (error) {
    console.error('Error creating evento:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await request.json();
    const { id, nombre, descripcion, fechaEvento, badge, publicado, orden } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    const evento = await db.evento.update({
      where: { id },
      data: {
        ...(nombre !== undefined && { nombre }),
        ...(descripcion !== undefined && { descripcion }),
        ...(fechaEvento !== undefined && { fechaEvento }),
        ...(badge !== undefined && { badge }),
        ...(publicado !== undefined && { publicado }),
        ...(orden !== undefined && { orden }),
      },
    });

    return NextResponse.json(evento);
  } catch (error) {
    console.error('Error updating evento:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await authenticate(request);
  if (!auth) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID es requerido' }, { status: 400 });
    }

    await db.evento.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting evento:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
