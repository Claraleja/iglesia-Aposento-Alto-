import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const iglesia = await db.iglesia.findFirst({
      include: {
        contacto: true,
        hero: true,
        donacionesCfg: true,
        oracionCfg: true,
      },
    });

    if (!iglesia) {
      return NextResponse.json({ error: 'Iglesia no encontrada' }, { status: 404 });
    }

    const id = iglesia.id;

    const [
      pastores,
      horarios,
      predicas,
      eventos,
      recursosNinos,
      porcarts,
      galeriaItems,
      testimonios,
      oracionDias,
      oracionHorarios,
    ] = await Promise.all([
      db.pastor.findMany({ where: { iglesiaId: id, activo: true }, orderBy: { orden: 'asc' } }),
      db.horario.findMany({ where: { iglesiaId: id, activo: true }, orderBy: { orden: 'asc' } }),
      db.predica.findMany({ where: { iglesiaId: id, publicada: true }, orderBy: { orden: 'asc' } }),
      db.evento.findMany({ where: { iglesiaId: id, publicado: true }, orderBy: { fechaEvento: 'desc' } }),
      db.recursoNino.findMany({ where: { iglesiaId: id, publicado: true }, orderBy: { orden: 'asc' } }),
      db.porcart.findMany({ where: { iglesiaId: id, activo: true }, orderBy: { orden: 'asc' } }),
      db.galeriaItem.findMany({ where: { iglesiaId: id, publicada: true }, orderBy: { orden: 'asc' } }),
      db.testimonio.findMany({ where: { iglesiaId: id, publicado: true }, orderBy: { orden: 'asc' } }),
      db.oracionDia.findMany({ where: { iglesiaId: id }, orderBy: { orden: 'asc' } }),
      db.oracionHorario.findMany({ where: { iglesiaId: id }, orderBy: { orden: 'asc' } }),
    ]);

    return NextResponse.json({
      iglesia: {
        id: iglesia.id,
        nombre: iglesia.nombre,
        slug: iglesia.slug,
        letra: iglesia.letra,
        logoUrl: iglesia.logoUrl,
        versiculo: iglesia.versiculo,
        versiculoRef: iglesia.versiculoRef,
        mision: iglesia.mision,
      },
      contacto: iglesia.contacto,
      hero: iglesia.hero,
      pastor: pastores[0] ?? null,
      horarios,
      predicas,
      eventos,
      ninos: recursosNinos,
      porcarts,
      galeria: galeriaItems,
      testimonios,
      donaciones: iglesia.donacionesCfg,
      oracion: iglesia.oracionCfg,
      oracionDias,
      oracionHorarios,
    });
  } catch (error) {
    console.error('Error fetching iglesia data:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}