'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'
import { IglesiaData } from '@/lib/types'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetClose,
} from '@/components/ui/sheet'
import {
  Menu,
  X,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Clock,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Heart,
  Play,
  Pause,
  Plus,
  Trash2,
  Edit,
  Save,
  Quote,
  Send,
  Settings,
  Loader2,
  Image as ImageIcon,
  MessageSquare,
  Users,
  BookOpen,
  Star,
} from 'lucide-react'

/* ─────────────── SVG Icons ─────────────── */

function CrossIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="16" y="4" width="8" height="32" rx="1.5" fill="currentColor" />
      <rect x="6" y="14" width="28" height="8" rx="1.5" fill="currentColor" />
    </svg>
  )
}

function FacebookIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  )
}

function InstagramIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
    </svg>
  )
}

function YoutubeIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
    </svg>
  )
}

function WhatsAppIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

/* ─────────────── Animation Variants ─────────────── */

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
}

const stagger = {
  visible: { transition: { staggerChildren: 0.1 } },
}

/* ─────────────── NAV LINKS ─────────────── */

const NAV_LINKS = [
  { label: 'Horarios', id: 'horarios' },
  { label: 'Predicas', id: 'predicas' },
  { label: 'Niños', id: 'ninos' },
  { label: 'Eventos', id: 'eventos' },
  { label: 'Nosotros', id: 'sobre' },
  { label: 'Oración', id: 'oracion' },
]

/* ─────────────── Placeholder Gallery Images ─────────────── */

const PLACEHOLDER_GALLERY = [
  'https://picsum.photos/seed/church1/800/600',
  'https://picsum.photos/seed/church2/800/600',
  'https://picsum.photos/seed/church3/800/600',
  'https://picsum.photos/seed/church4/800/600',
  'https://picsum.photos/seed/church5/800/600',
  'https://picsum.photos/seed/church6/800/600',
]

/* ─────────────── Main Component ─────────────── */

export default function Home() {
  const { toast } = useToast()

  /* ── State ── */
  const [data, setData] = useState<IglesiaData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [adminOpen, setAdminOpen] = useState(false)
  const [adminToken, setAdminToken] = useState<string | null>(null)
  const [adminLoggedIn, setAdminLoggedIn] = useState(false)
  const [adminLoginLoading, setAdminLoginLoading] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [playingAudio, setPlayingAudio] = useState<string | null>(null)
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null)
  const [selectedImage, setSelectedImage] = useState<{ url: string; caption: string } | null>(null)
  const [imageDialogOpen, setImageDialogOpen] = useState(false)
  const [contactForm, setContactForm] = useState({ nombre: '', email: '', telefono: '', mensaje: '' })
  const [contactSending, setContactSending] = useState(false)

  // Admin state
  const [adminTab, setAdminTab] = useState('iglesia')
  const [adminData, setAdminData] = useState<Record<string, unknown[]>>({})
  const [adminFormState, setAdminFormState] = useState<Record<string, Record<string, string | boolean>>>({})
  const [adminEditingId, setAdminEditingId] = useState<string | null>(null)

  const mainRef = useRef<HTMLDivElement>(null)
  const audioElRef = useRef<HTMLAudioElement>(null)

  /* ── Fetch Data ── */
  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch('/api/iglesia')
        if (!res.ok) throw new Error('Error al cargar datos')
        const json = await res.json()
        setData(json)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido')
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  /* ── Scroll Listener ── */
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  /* ── Smooth scroll ── */
  const scrollTo = useCallback((id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMobileMenuOpen(false)
  }, [])

  /* ── Audio Player ── */
  const toggleAudio = useCallback((url: string) => {
    if (playingAudio === url) {
      audioElRef.current?.pause()
      setPlayingAudio(null)
    } else {
      if (audioElRef.current) {
        audioElRef.current.src = url
        audioElRef.current.play().catch(() => {
          toast({ title: 'No se pudo reproducir el audio', variant: 'destructive' })
        })
      }
      setPlayingAudio(url)
    }
  }, [playingAudio, toast])

  /* ── Contact Form → WhatsApp ── */
  const handleContactSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault()
    if (!contactForm.nombre || !contactForm.mensaje) {
      toast({ title: 'Completa los campos requeridos', variant: 'destructive' })
      return
    }
    const wa = data?.contacto?.whatsapp || '525512345678'
    const text = [
      `*Nuevo mensaje de contacto*`,
      ``,
      `👤 Nombre: ${contactForm.nombre}`,
      contactForm.email ? `📧 Email: ${contactForm.email}` : '',
      contactForm.telefono ? `📱 Teléfono: ${contactForm.telefono}` : '',
      ``,
      `💬 Mensaje:`,
      `${contactForm.mensaje}`,
    ].filter(Boolean).join('\n')
    const waUrl = `https://wa.me/${wa}?text=${encodeURIComponent(text)}`
    window.open(waUrl, '_blank')
    toast({ title: '¡Abriendo WhatsApp!', description: 'Tu mensaje se enviará por WhatsApp.' })
    setContactForm({ nombre: '', email: '', telefono: '', mensaje: '' })
  }, [contactForm, data?.contacto?.whatsapp, toast])

  /* ── Admin Login ── */
  const handleAdminLogin = useCallback(async () => {
    setAdminLoginLoading(true)
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'admin@iglesia.com', password: adminPassword }),
      })
      const json = await res.json()
      if (!res.ok || !json.success) {
        toast({ title: 'Credenciales inválidas', variant: 'destructive' })
        return
      }
      setAdminToken(json.token)
      setAdminLoggedIn(true)
      setAdminPassword('')
      toast({ title: 'Sesión iniciada' })
    } catch {
      toast({ title: 'Error de conexión', variant: 'destructive' })
    } finally {
      setAdminLoginLoading(false)
    }
  }, [adminPassword, toast])

  /* ── Admin API Helper ── */
  const adminFetch = useCallback(async (module: string, options?: RequestInit) => {
    const res = await fetch(`/api/admin/${module}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        ...options?.headers,
      },
    })
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error de servidor' }))
      throw new Error(err.error || 'Error de servidor')
    }
    return res.json()
  }, [adminToken])

  /* ── Admin CRUD Generic ── */
  const adminLoadModule = useCallback(async (module: string) => {
    try {
      const items = await adminFetch(module)
      setAdminData(prev => ({ ...prev, [module]: items }))
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error al cargar', variant: 'destructive' })
    }
  }, [adminFetch, toast])

  const adminCreate = useCallback(async (module: string, formData: Record<string, unknown>) => {
    try {
      await adminFetch(module, { method: 'POST', body: JSON.stringify(formData) })
      toast({ title: 'Creado exitosamente' })
      adminLoadModule(module)
      setAdminEditingId(null)
      setAdminFormState(prev => ({ ...prev, [module]: {} }))
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error al crear', variant: 'destructive' })
    }
  }, [adminFetch, adminLoadModule, toast])

  const adminUpdate = useCallback(async (module: string, id: string, formData: Record<string, unknown>) => {
    try {
      await adminFetch(module, { method: 'PUT', body: JSON.stringify({ id, ...formData }) })
      toast({ title: 'Actualizado exitosamente' })
      adminLoadModule(module)
      setAdminEditingId(null)
      setAdminFormState(prev => ({ ...prev, [module]: {} }))
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error al actualizar', variant: 'destructive' })
    }
  }, [adminFetch, adminLoadModule, toast])

  const adminDelete = useCallback(async (module: string, id: string) => {
    if (!confirm('¿Eliminar este elemento?')) return
    try {
      await adminFetch(`${module}?id=${id}`, { method: 'DELETE' })
      toast({ title: 'Eliminado' })
      adminLoadModule(module)
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error al eliminar', variant: 'destructive' })
    }
  }, [adminFetch, adminLoadModule, toast])

  /* ── Load admin data when tab changes ── */
  useEffect(() => {
    if (adminLoggedIn && adminToken) {
      const modules = ['horarios', 'predicas', 'eventos', 'ninos', 'galeria', 'testimonios', 'porcarts']
      modules.forEach(m => adminLoadModule(m))
    }
  }, [adminLoggedIn, adminToken, adminLoadModule])

  /* ── Refresh public data after admin changes ── */
  const refreshPublicData = useCallback(async () => {
    try {
      const res = await fetch('/api/iglesia')
      if (res.ok) setData(await res.json())
    } catch { /* ignore */ }
  }, [])

  /* ─────────────────────────── RENDER ─────────────────────────── */

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: '#0E0C0A' }}>
        <CrossIcon className="w-16 h-16 text-[#C9A84C] animate-pulse-gold" />
        <p className="text-[#9A9080] text-lg" style={{ fontFamily: "'Cormorant Garamond', serif" }}>Cargando...</p>
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: '#0E0C0A' }}>
        <CrossIcon className="w-16 h-16 text-red-500" />
        <p className="text-red-400 text-lg">{error || 'No se encontraron datos'}</p>
        <Button onClick={() => window.location.reload()} variant="outline" className="outline-btn">Reintentar</Button>
      </div>
    )
  }

  const churchName = data.iglesia?.nombre || 'Iglesia Aposento Alto'
  const churchLetter = data.iglesia?.letra || 'A'
  const churchLogo = data.iglesia?.logoUrl || ''
  const heroImage = data.hero?.imagenUrl || ''
  const verse = data.iglesia?.versiculo || ''
  const verseRef = data.iglesia?.versiculoRef || ''
  const contacto = data.contacto
  const pastor = data.pastor
  const horarios = data.horarios || []
  const predicas = data.predicas || []
  const ninos = data.ninos || []
  const eventos = data.eventos || []
  const porcarts = data.porcarts || []
  const galeria = data.galeria || []
  const testimonios = data.testimonios || []
  const donaciones = data.donaciones
  const oracion = data.oracion
  const oracionDias = data.oracionDias || []
  const oracionHorarios = data.oracionHorarios || []

  const heroBgStyle = heroImage
    ? { backgroundImage: `url(${heroImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : {}

  const galleryImages = galeria.length > 0 ? galeria : PLACEHOLDER_GALLERY.map((url, i) => ({ id: `ph-${i}`, imagenUrl: url, caption: `Foto ${i + 1}`, publicada: true, orden: i }))

  // Group horarios by day
  const horariosByDay = horarios.reduce<Record<string, typeof horarios>>((acc, h) => {
    if (!acc[h.dia]) acc[h.dia] = []
    acc[h.dia].push(h)
    return acc
  }, {})

  const formatDate = (dateStr: string) => {
    if (!dateStr) return ''
    try {
      const d = new Date(dateStr + 'T12:00:00')
      return d.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' })
    } catch {
      return dateStr
    }
  }

  const footerSlogan = data.hero?.footerSlogan || 'Todos son bienvenidos.'
  const footerAnio = data.hero?.footerAnio || new Date().getFullYear().toString()

  /* ════════════════════════════════════════════════════════════════ */
  /*  RENDER                                                           */
  /* ════════════════════════════════════════════════════════════════ */

  return (
    <div ref={mainRef} className="min-h-screen flex flex-col" style={{ background: '#0E0C0A' }}>
      {/* Hidden audio element */}
      <audio ref={audioElRef} onEnded={() => setPlayingAudio(null)} />

      {/* ═════════════ 1. HEADER / NAVIGATION ═════════════ */}
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? 'rgba(14, 12, 10, 0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(12px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(201, 168, 76, 0.15)' : '1px solid transparent',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16 lg:h-18">
          {/* Logo */}
          <button onClick={() => scrollTo('hero')} className="flex items-center gap-3">
            {churchLogo && churchLogo !== '/logo-placeholder.png' ? (
              <img src={churchLogo} alt={churchName} className="w-10 h-10 rounded-lg object-cover" />
            ) : (
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-[#C9A84C]" style={{ background: 'rgba(201, 168, 76, 0.15)' }}>
                <CrossIcon className="w-5 h-5" />
              </div>
            )}
            <span className="hidden sm:block text-[#E8E2D5] font-semibold tracking-wide" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(1.05rem, 1.5vw, 1.35rem)' }}>
              {churchName}
            </span>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map(link => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="px-3 py-2 text-sm text-[#9A9080] hover:text-[#E8C97A] rounded-lg transition-colors duration-200"
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => setAdminOpen(true)}
              className="ml-3 p-2 rounded-lg text-[#9A9080] hover:text-[#C9A84C] transition-colors duration-200"
              title="Administración"
            >
              <Settings className="w-4 h-4" />
            </button>
          </nav>

          {/* Mobile Menu */}
          <div className="flex items-center gap-2 lg:hidden">
            <button onClick={() => setAdminOpen(true)} className="p-2 text-[#9A9080]">
              <Settings className="w-4 h-4" />
            </button>
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <button className="p-2 text-[#E8E2D5]">
                  <Menu className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72" style={{ background: '#1A1713', borderLeft: '1px solid rgba(201, 168, 76, 0.18)' }}>
                <SheetHeader>
                  <SheetTitle className="text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.5rem' }}>
                    Menú
                  </SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col gap-1 mt-4">
                  {NAV_LINKS.map(link => (
                    <SheetClose asChild key={link.id}>
                      <button
                        onClick={() => scrollTo(link.id)}
                        className="flex items-center gap-3 px-4 py-3 text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.08)] rounded-lg transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                        {link.label}
                      </button>
                    </SheetClose>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* ═════════════ 2. HERO SECTION ═════════════ */}
      <section
        id="hero"
        className="relative min-h-screen flex items-center justify-center text-center px-4"
        style={heroImage ? { ...heroBgStyle } : { background: 'linear-gradient(135deg, #0E0C0A 0%, #1A1713 40%, #252118 100%)' }}
      >
        {heroImage && (
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(14,12,10,0.7), rgba(14,12,10,0.5), rgba(14,12,10,0.85))' }} />
        )}
        <div className="relative z-10 max-w-3xl md:max-w-4xl lg:max-w-5xl mx-auto">
          <motion.div initial="hidden" animate="visible" variants={stagger}>
            <motion.div variants={fadeUp} className="mb-6">
              {churchLogo && churchLogo !== '/logo-placeholder.png' ? (
                <img src={churchLogo} alt={churchName} className="w-20 h-20 lg:w-24 lg:h-24 rounded-2xl mx-auto object-cover mb-4 border border-[rgba(201,168,76,0.3)]" />
              ) : (
                <div className="w-20 h-20 lg:w-24 lg:h-24 rounded-2xl mx-auto flex items-center justify-center mb-4 border border-[rgba(201,168,76,0.3)]" style={{ background: 'rgba(201, 168, 76, 0.12)' }}>
                  <CrossIcon className="w-10 h-10 lg:w-12 lg:h-12 text-[#C9A84C]" />
                </div>
              )}
            </motion.div>
            <motion.h1
              variants={fadeUp}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-semibold mb-6 lg:mb-8"
              style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C', lineHeight: 1.15 }}
            >
              {churchName}
            </motion.h1>
            {verse && (
              <motion.p
                variants={fadeUp}
                className="text-lg sm:text-xl md:text-2xl lg:text-3xl italic mb-3 lg:mb-4 max-w-2xl lg:max-w-3xl mx-auto"
                style={{ fontFamily: "'Cormorant Garamond', serif", color: '#E8E2D5', fontWeight: 400 }}
              >
                &ldquo;{verse}&rdquo;
              </motion.p>
            )}
            {verseRef && (
              <motion.p variants={fadeUp} className="text-sm" style={{ color: '#E8C97A' }}>
                — {verseRef}
              </motion.p>
            )}
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 1 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <button onClick={() => scrollTo('horarios')} className="animate-pulse-gold">
              <ChevronDown className="w-6 h-6 text-[#C9A84C]" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* ═════════════ 3. HORARIOS ═════════════ */}
      <section id="horarios" className="section-container">
        <div className="section-title">
          <h2>Nuestros Horarios</h2>
          <p>Te esperamos con los brazos abiertos en cada reunión.</p>
        </div>
        {Object.keys(horariosByDay).length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 lg:gap-6"
          >
            {Object.entries(horariosByDay).map(([day, items]) => (
              <motion.div key={day} variants={fadeUp} className="glass-card">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-5 h-5 text-[#C9A84C]" />
                  <h3 className="text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.3rem' }}>{day}</h3>
                </div>
                <div className="flex flex-col gap-3">
                  {items.map(h => (
                    <div key={h.id} className="flex items-center gap-3">
                      <Clock className="w-4 h-4 text-[#9A9080] shrink-0" />
                      <div className="flex-1">
                        <p className="text-[#E8E2D5] text-sm">{h.servicio}</p>
                        <p className="text-[#9A9080] text-xs">{h.hora}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="glass-card text-center">
            <Clock className="w-10 h-10 mx-auto mb-3 text-[#9A9080]" />
            <p className="text-[#9A9080]">Próximamente horarios disponibles</p>
          </div>
        )}
      </section>

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 4. PREDICAS ═════════════ */}
      <section id="predicas" className="section-container">
        <div className="section-title">
          <h2>Predicas</h2>
          <p>Escucha y fortalece tu fe con la Palabra de Dios.</p>
        </div>
        {predicas.length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 lg:gap-6"
          >
            {predicas.map(p => (
              <motion.div key={p.id} variants={fadeUp} className="glass-card overflow-hidden group">
                <div className="relative aspect-video overflow-hidden">
                  {p.imagenUrl ? (
                    <img src={p.imagenUrl} alt={p.titulo} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #252118, #302B20)' }}>
                      <BookOpen className="w-12 h-12 text-[#9A9080]" />
                    </div>
                  )}
                  {p.serie && (
                    <Badge className="absolute top-3 left-3 text-xs" style={{ background: 'rgba(201, 168, 76, 0.9)', color: '#0E0C0A', border: 'none' }}>
                      {p.serie}
                    </Badge>
                  )}
                  {(p.audioUrl || p.spotifyUrl) && (
                    <button
                      onClick={() => p.audioUrl && toggleAudio(p.audioUrl)}
                      className="absolute bottom-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200"
                      style={{
                        background: playingAudio === p.audioUrl ? 'rgba(201, 168, 76, 0.9)' : 'rgba(14, 12, 10, 0.8)',
                        border: '1px solid rgba(201, 168, 76, 0.3)',
                      }}
                    >
                      {playingAudio === p.audioUrl ? (
                        <Pause className="w-4 h-4 text-[#0E0C0A]" />
                      ) : (
                        <Play className="w-4 h-4 text-[#C9A84C]" />
                      )}
                    </button>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="mb-1 text-[#E8E2D5]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.15rem' }}>{p.titulo}</h3>
                  <p className="text-[#9A9080] text-sm">{p.predicador}</p>
                  <p className="text-[#9A9080] text-xs mt-1">{formatDate(p.fechaPredica)}</p>
                  {p.spotifyUrl && (
                    <a href={p.spotifyUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 mt-2 text-xs text-[#C9A84C] hover:text-[#E8C97A]">
                      <Play className="w-3 h-3" /> Escuchar en Spotify
                    </a>
                  )}
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="glass-card text-center">
            <BookOpen className="w-10 h-10 mx-auto mb-3 text-[#9A9080]" />
            <p className="text-[#9A9080]">Próximamente predicas disponibles</p>
          </div>
        )}
      </section>

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 5. NIÑOS ═════════════ */}
      <section id="ninos" className="section-container">
        <div className="section-title">
          <h2>Ministerio de Niños</h2>
          <p>Recursos para los más pequeños de la casa.</p>
        </div>
        {ninos.length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 sm:gap-5 lg:gap-6"
          >
            {ninos.map(n => (
              <motion.div key={n.id} variants={fadeUp} className="glass-card overflow-hidden group">
                <div className="relative aspect-[4/3] overflow-hidden">
                  {n.imagenUrl ? (
                    <img src={n.imagenUrl} alt={n.nombre} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #252118, #302B20)' }}>
                      <Star className="w-10 h-10 text-[#C9A84C]" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <Badge className="mb-2 text-xs" style={{ background: 'rgba(201, 168, 76, 0.15)', color: '#C9A84C', border: '1px solid rgba(201, 168, 76, 0.3)' }}>
                    {n.tipo}
                  </Badge>
                  <h3 className="text-[#E8E2D5] mb-3" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.05rem' }}>{n.nombre}</h3>
                  <a
                    href={n.recursoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="gold-btn text-xs"
                    style={{ padding: '0.4rem 1rem', fontSize: '0.75rem' }}
                  >
                    Ver Recurso
                  </a>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="glass-card text-center">
            <Star className="w-10 h-10 mx-auto mb-3 text-[#9A9080]" />
            <p className="text-[#9A9080]">Próximamente recursos para niños</p>
          </div>
        )}
      </section>

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 6. EVENTOS ═════════════ */}
      <section id="eventos" className="section-container">
        <div className="section-title">
          <h2>Próximos Eventos</h2>
          <p>No te pierdas las actividades especiales.</p>
        </div>
        {eventos.length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={stagger}
            className="flex flex-col gap-4"
          >
            {eventos.map(e => (
              <motion.div key={e.id} variants={fadeUp} className="glass-card flex flex-col sm:flex-row gap-4 sm:gap-6">
                <div className="shrink-0 w-full sm:w-24 flex flex-col items-center justify-center rounded-lg p-3" style={{ background: 'rgba(201, 168, 76, 0.1)', border: '1px solid rgba(201, 168, 76, 0.2)' }}>
                  <Calendar className="w-5 h-5 text-[#C9A84C] mb-1" />
                  <span className="text-[#C9A84C] text-xs font-semibold">{formatDate(e.fechaEvento).split(' ').slice(0, 2).join(' ')}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="text-[#E8E2D5]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.2rem' }}>{e.nombre}</h3>
                    {e.badge && (
                      <Badge className="text-xs" style={{ background: 'rgba(201, 168, 76, 0.15)', color: '#C9A84C', border: '1px solid rgba(201, 168, 76, 0.3)' }}>
                        {e.badge}
                      </Badge>
                    )}
                  </div>
                  <p className="text-[#9A9080] text-sm">{e.descripcion}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="glass-card text-center">
            <Calendar className="w-10 h-10 mx-auto mb-3 text-[#9A9080]" />
            <p className="text-[#9A9080]">No hay eventos próximos</p>
          </div>
        )}
      </section>

      {/* ═════════════ 7. PORCARTS ═════════════ */}
      {porcarts.length > 0 && (
        <section id="porcarts" className="py-16 sm:py-20">
          <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 px-4 sm:px-6 pb-4 scrollbar-hide" style={{ scrollbarWidth: 'none' }}>
            {porcarts.map(pc => (
              <div
                key={pc.id}
                className="snap-center shrink-0 w-[85vw] sm:w-[60vw] md:w-[45vw] lg:w-[35vw] rounded-[10px] overflow-hidden relative"
                style={{ minHeight: '280px' }}
              >
                {pc.bgUrl ? (
                  <img src={pc.bgUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
                ) : null}
                <div className="absolute inset-0" style={{ background: pc.bgUrl ? 'linear-gradient(to top, rgba(14,12,10,0.9), rgba(14,12,10,0.4))' : 'linear-gradient(135deg, #1A1713, #252118)' }} />
                <div className="relative z-10 h-full flex flex-col items-center justify-center p-6 sm:p-10 text-center">
                  <p className="text-lg sm:text-xl md:text-2xl italic max-w-lg leading-relaxed" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#E8E2D5', fontWeight: 400 }}>
                    &ldquo;{pc.texto}&rdquo;
                  </p>
                  {pc.referencia && (
                    <p className="mt-3 text-sm font-semibold" style={{ color: '#E8C97A' }}>
                      — {pc.referencia}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ═════════════ 8. GALERIA ═════════════ */}
      <section id="galeria" className="section-container">
        <div className="section-title">
          <h2>Galeria</h2>
          <p>Momentos especiales de nuestra comunidad.</p>
        </div>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={stagger}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-3 sm:gap-4 lg:gap-5"
        >
          {galleryImages.map(g => (
            <motion.div
              key={g.id}
              variants={fadeUp}
              className="relative aspect-[4/3] rounded-[10px] overflow-hidden group cursor-pointer"
              onClick={() => {
                setSelectedImage({ url: g.imagenUrl, caption: 'caption' in g ? (g as { caption: string }).caption : '' })
                setImageDialogOpen(true)
              }}
            >
              <img
                src={g.imagenUrl}
                alt={'caption' in g ? (g as { caption: string }).caption : 'Galería'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-end">
                {'caption' in g && (g as { caption: string }).caption && (
                  <div className="p-3 w-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="text-white text-sm truncate">{(g as { caption: string }).caption}</p>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Image Dialog */}
      <Dialog open={imageDialogOpen} onOpenChange={setImageDialogOpen}>
        <DialogContent className="w-[calc(100vw-2rem)] max-w-5xl p-2" style={{ background: '#0E0C0A', border: '1px solid rgba(201, 168, 76, 0.2)' }}>
          {selectedImage && (
            <>
              <DialogTitle className="sr-only">{selectedImage.caption || 'Imagen'}</DialogTitle>
              <DialogDescription className="sr-only">Vista ampliada</DialogDescription>
              <img src={selectedImage.url} alt={selectedImage.caption} className="w-full rounded-lg" />
              {selectedImage.caption && (
                <p className="text-center text-[#9A9080] text-sm py-2">{selectedImage.caption}</p>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 9. TESTIMONIOS ═════════════ */}
      <section className="section-container">
        <div className="section-title">
          <h2>Testimonios</h2>
          <p>Historias de vidas transformadas por el poder de Dios.</p>
        </div>
        {testimonios.length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={stagger}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 lg:gap-6"
          >
            {testimonios.map(t => (
              <motion.div key={t.id} variants={fadeUp} className="glass-card relative">
                <Quote className="w-8 h-8 text-[rgba(201,168,76,0.2)] absolute top-4 right-4" />
                <p className="text-[#E8E2D5] text-sm leading-relaxed mb-4 relative z-10 italic">
                  &ldquo;{t.texto}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold" style={{ background: 'rgba(201, 168, 76, 0.15)', color: '#C9A84C' }}>
                    {t.autor.charAt(0)}
                  </div>
                  <p className="text-[#C9A84C] text-sm font-medium">{t.autor}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="glass-card text-center">
            <Heart className="w-10 h-10 mx-auto mb-3 text-[#9A9080]" />
            <p className="text-[#9A9080]">Próximamente testimonios</p>
          </div>
        )}
      </section>

      {/* ═════════════ 10. DONACIONES ═════════════ */}
      {donaciones?.activo && (
        <>
          <div className="divider max-w-7xl mx-auto" />
          <section id="donaciones" className="section-container text-center">
            <div className="section-title">
              <h2>Donaciones</h2>
            </div>
            <div className="max-w-lg mx-auto glass-card">
              <Heart className="w-10 h-10 mx-auto mb-4 text-[#C9A84C]" />
              <p className="text-[#E8E2D5] mb-6">{donaciones.mensaje || 'Tu generosidad hace posible el ministerio.'}</p>
              {donaciones.urlPago && donaciones.urlPago !== '#' && (
                <a href={donaciones.urlPago} target="_blank" rel="noopener noreferrer" className="gold-btn">
                  <Heart className="w-4 h-4" /> Donar Ahora
                </a>
              )}
            </div>
          </section>
        </>
      )}

      {/* ═════════════ 11. ORACIÓN ═════════════ */}
      {oracion?.activo && (
        <>
          <div className="divider max-w-7xl mx-auto" />
          <section id="oracion" className="section-container text-center">
            <div className="section-title">
              <h2>Oración</h2>
            </div>
            <div className="max-w-lg mx-auto glass-card">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(201, 168, 76, 0.12)' }}>
                <CrossIcon className="w-8 h-8 text-[#C9A84C]" />
              </div>
              <p className="text-[#E8E2D5] mb-4">{oracion.descripcion || 'Estamos aquí para orar contigo.'}</p>
              {oracionDias.length > 0 && (
                <div className="flex flex-wrap justify-center gap-2 mb-4">
                  {oracionDias.map(d => (
                    <Badge key={d.id} className="text-xs" style={{ background: 'rgba(201, 168, 76, 0.1)', color: '#C9A84C', border: '1px solid rgba(201, 168, 76, 0.25)' }}>
                      {d.dia}
                    </Badge>
                  ))}
                </div>
              )}
              {oracionHorarios.length > 0 && (
                <div className="flex flex-col gap-1 mb-4 text-sm text-[#9A9080]">
                  {oracionHorarios.map(h => (
                    <p key={h.id}><Clock className="w-3 h-3 inline mr-1" />{h.rangoDias}: {h.hora}</p>
                  ))}
                </div>
              )}
              {oracion.whatsapp && (
                <a
                  href={`https://wa.me/${oracion.whatsapp}?text=${encodeURIComponent('Necesito oración. Mi petición es: ')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gold-btn inline-flex items-center gap-2"
                >
                  <WhatsAppIcon className="w-4 h-4" /> Enviar Petición de Oración
                </a>
              )}
            </div>
          </section>
        </>
      )}

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 12. NOSOTROS ═════════════ */}
      <section id="sobre" className="section-container">
        <div className="section-title">
          <h2>Nosotros</h2>
          <p>Conoce a nuestro pastor y nuestra misión.</p>
        </div>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={stagger}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 lg:gap-10 items-center"
        >
          {/* Pastor */}
          {pastor && (
            <motion.div variants={fadeUp} className="glass-card flex flex-col items-center text-center p-6 sm:p-8 lg:p-10">
              {pastor.fotoUrl ? (
                <img src={pastor.fotoUrl} alt={pastor.nombre} className="w-28 h-28 lg:w-36 lg:h-36 rounded-full object-cover mb-4 border-2 border-[rgba(201,168,76,0.3)]" />
              ) : (
                <div className="w-28 h-28 lg:w-36 lg:h-36 rounded-full flex items-center justify-center mb-4 text-2xl font-semibold" style={{ background: 'rgba(201, 168, 76, 0.12)', color: '#C9A84C', border: '2px solid rgba(201, 168, 76, 0.3)' }}>
                  {pastor.iniciales || pastor.nombre.charAt(0)}
                </div>
              )}
              <h3 className="text-xl mb-1" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C' }}>{pastor.nombre}</h3>
              <p className="text-[#9A9080] text-sm mb-4">{pastor.rol}</p>
              {pastor.bio && <p className="text-[#9A9080] text-sm leading-relaxed">{pastor.bio}</p>}
            </motion.div>
          )}

          {/* Mission */}
          <motion.div variants={fadeUp} className="glass-card p-6 sm:p-8">
            <div className="flex items-center gap-2 mb-4">
              <CrossIcon className="w-6 h-6 text-[#C9A84C]" />
              <h3 className="text-xl" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C' }}>Nuestra Misión</h3>
            </div>
            <p className="text-[#E8E2D5] text-base leading-relaxed">
              {data.iglesia?.mision || 'Llevar la esperanza del evangelio a toda familia.'}
            </p>
            {contacto?.direccion && (
              <div className="mt-6 flex items-start gap-2 text-sm text-[#9A9080]">
                <MapPin className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
                <span>{contacto.direccion}</span>
              </div>
            )}
          </motion.div>
        </motion.div>
      </section>

      <div className="divider max-w-7xl mx-auto" />

      {/* ═════════════ 13. CONTACTO ═════════════ */}
      <section id="contacto" className="section-container">
        <div className="section-title">
          <h2>Contacto</h2>
          <p>¿Tienes alguna pregunta? Escríbenos.</p>
        </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 sm:gap-8">
          {/* Contact Form */}
          <form onSubmit={handleContactSubmit} className="glass-card p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <Label htmlFor="contact-name" className="text-[#9A9080] text-xs mb-1 block">Nombre *</Label>
                <Input
                  id="contact-name"
                  value={contactForm.nombre}
                  onChange={e => setContactForm(p => ({ ...p, nombre: e.target.value }))}
                  placeholder="Tu nombre"
                  required
                  className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 focus:border-[#C9A84C]"
                />
              </div>
              <div>
                <Label htmlFor="contact-email" className="text-[#9A9080] text-xs mb-1 block">Email</Label>
                <Input
                  id="contact-email"
                  type="email"
                  value={contactForm.email}
                  onChange={e => setContactForm(p => ({ ...p, email: e.target.value }))}
                  placeholder="tu@email.com (opcional)"
                  className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 focus:border-[#C9A84C]"
                />
              </div>
            </div>
            <div className="mb-4">
              <Label htmlFor="contact-phone" className="text-[#9A9080] text-xs mb-1 block">Teléfono</Label>
              <Input
                id="contact-phone"
                value={contactForm.telefono}
                onChange={e => setContactForm(p => ({ ...p, telefono: e.target.value }))}
                placeholder="+52 55 1234 5678"
                className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 focus:border-[#C9A84C]"
              />
            </div>
            <div className="mb-6">
              <Label htmlFor="contact-message" className="text-[#9A9080] text-xs mb-1 block">Mensaje *</Label>
              <Textarea
                id="contact-message"
                value={contactForm.mensaje}
                onChange={e => setContactForm(p => ({ ...p, mensaje: e.target.value }))}
                placeholder="Escribe tu mensaje..."
                rows={4}
                required
                className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 focus:border-[#C9A84C] resize-none"
              />
            </div>
            <Button type="submit" className="gold-btn w-full justify-center">
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              Enviar por WhatsApp
            </Button>
          </form>

          {/* Contact Info */}
          <div className="glass-card p-6">
            <h3 className="text-lg mb-6" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C' }}>Información</h3>
            <div className="flex flex-col gap-4 mb-8">
              {contacto?.direccion && (
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
                  <span className="text-[#9A9080] text-sm">{contacto.direccion}</span>
                </div>
              )}
              {contacto?.telefono && (
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <a href={`tel:${contacto.telefono}`} className="text-[#9A9080] text-sm hover:text-[#C9A84C]">{contacto.telefono}</a>
                </div>
              )}
              {contacto?.email && (
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <a href={`mailto:${contacto.email}`} className="text-[#9A9080] text-sm hover:text-[#C9A84C]">{contacto.email}</a>
                </div>
              )}
            </div>

            {/* Social Links */}
            <h4 className="text-sm mb-3" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C' }}>Síguenos</h4>
            <div className="flex items-center gap-3">
              {contacto?.facebookUrl && (
                <a href={contacto.facebookUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                  <FacebookIcon />
                </a>
              )}
              {contacto?.instagramUrl && (
                <a href={contacto.instagramUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                  <InstagramIcon />
                </a>
              )}
              {contacto?.youtubeUrl && (
                <a href={contacto.youtubeUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                  <YoutubeIcon />
                </a>
              )}
              {contacto?.whatsapp && (
                <a href={`https://wa.me/${contacto.whatsapp}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                  <WhatsAppIcon />
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ═════════════ 14. FOOTER ═════════════ */}
      <footer className="mt-auto py-10 sm:py-14 lg:py-16 px-4 sm:px-6 lg:px-8" style={{ background: '#0E0C0A', borderTop: '1px solid rgba(201, 168, 76, 0.12)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12 mb-8 items-center">
            {/* Church Info */}
            <div className="flex flex-col items-center md:items-start text-center md:text-left gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'rgba(201, 168, 76, 0.12)' }}>
                <CrossIcon className="w-5 h-5 text-[#C9A84C]" />
              </div>
              <h3 className="text-xl lg:text-2xl" style={{ fontFamily: "'Cormorant Garamond', serif", color: '#C9A84C' }}>{churchName}</h3>
              <p className="text-[#9A9080] text-sm">{footerSlogan}</p>
            </div>

            {/* Quick Links */}
            <nav className="flex flex-col items-center gap-2">
              {NAV_LINKS.map(link => (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className="text-[#9A9080] hover:text-[#C9A84C] text-sm transition-colors duration-200"
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Social Links */}
            <div className="flex flex-col items-center md:items-end gap-3">
              <p className="text-xs text-[#9A9080] uppercase tracking-widest">Síguenos</p>
              <div className="flex items-center gap-3">
                {contacto?.facebookUrl && (
                  <a href={contacto.facebookUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                    <FacebookIcon className="w-4 h-4" />
                  </a>
                )}
                {contacto?.instagramUrl && (
                  <a href={contacto.instagramUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                    <InstagramIcon className="w-4 h-4" />
                  </a>
                )}
                {contacto?.youtubeUrl && (
                  <a href={contacto.youtubeUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                    <YoutubeIcon className="w-4 h-4" />
                  </a>
                )}
                {contacto?.whatsapp && (
                  <a href={`https://wa.me/${contacto.whatsapp}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg flex items-center justify-center text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-all duration-200" style={{ border: '1px solid rgba(201, 168, 76, 0.18)' }}>
                    <WhatsAppIcon className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
          <div className="divider mb-0" style={{ margin: '0' }} />
          <p className="text-center text-[#9A9080] text-xs mt-6">
            © {footerAnio} {churchName}. Todos los derechos reservados.
          </p>
        </div>
      </footer>

      {/* ═══════════════════════════════════════════════════════ */}
      {/*  ADMIN PANEL DIALOG                                         */}
      {/* ═══════════════════════════════════════════════════════ */}
      <Dialog open={adminOpen} onOpenChange={setAdminOpen}>
        <DialogContent className="w-[calc(100vw-2rem)] sm:w-[calc(100vw-4rem)] md:w-[calc(100vw-6rem)] lg:max-w-6xl xl:max-w-7xl max-h-[92vh] overflow-y-auto p-0" style={{ background: '#1A1713', border: '1px solid rgba(201, 168, 76, 0.2)' }}>
          <DialogHeader className="p-6 pb-2">
            <DialogTitle className="text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.5rem' }}>
              Panel de Administración
            </DialogTitle>
            <DialogDescription className="text-[#9A9080]">
              Gestiona el contenido de tu iglesia
            </DialogDescription>
          </DialogHeader>

          {!adminLoggedIn ? (
            /* ── Login Form ── */
            <div className="p-6">
              <div className="glass-card max-w-sm mx-auto p-6">
                <Label className="text-[#9A9080] text-sm mb-2 block">Contraseña de administrador</Label>
                <Input
                  type="password"
                  value={adminPassword}
                  onChange={e => setAdminPassword(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleAdminLogin()}
                  placeholder="Contraseña..."
                  className="mb-4 bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 focus:border-[#C9A84C]"
                />
                <Button onClick={handleAdminLogin} disabled={adminLoginLoading} className="gold-btn w-full justify-center">
                  {adminLoginLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  Iniciar Sesión
                </Button>
              </div>
            </div>
          ) : (
            /* ── Admin Tabs ── */
            <div className="p-4 sm:p-6 pt-2">
              <Tabs value={adminTab} onValueChange={setAdminTab}>
                <ScrollArea className="w-full" style={{ maxWidth: '100%' }}>
                  <TabsList className="flex-wrap gap-1 h-auto p-1 mb-6" style={{ background: '#252118' }}>
                    {[
                      { key: 'iglesia', label: 'Iglesia' },
                      { key: 'conocenos', label: 'Conócenos' },
                      { key: 'horarios', label: 'Horarios' },
                      { key: 'predicas', label: 'Predicas' },
                      { key: 'eventos', label: 'Eventos' },
                      { key: 'galeria', label: 'Galería' },
                      { key: 'testimonios', label: 'Testimonios' },
                      { key: 'ninos', label: 'Niños' },
                      { key: 'porcarts', label: 'Porcarts' },
                      { key: 'donaciones', label: 'Donaciones' },
                      { key: 'oracion', label: 'Oración' },
                      { key: 'mensajes', label: 'Mensajes' },
                      { key: 'miembros', label: 'Miembros' },
                    ].map(tab => (
                      <TabsTrigger key={tab.key} value={tab.key} className="text-xs px-2.5 sm:px-3 py-1.5 data-[state=active]:text-[#C9A84C] data-[state=active]:bg-[rgba(201,168,76,0.1)]">
                        {tab.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </ScrollArea>

                {/* ── Iglesia Tab ── */}
                <TabsContent value="iglesia">
                  <AdminIglesiaTab data={data} adminFetch={adminFetch} toast={toast} refreshData={refreshPublicData} />
                </TabsContent>

                {/* ── Conócenos Tab ── */}
                <TabsContent value="conocenos">
                  <AdminConocenosTab data={data} adminFetch={adminFetch} toast={toast} refreshData={refreshPublicData} />
                </TabsContent>

                {/* ── CRUD Tabs ── */}
                {['horarios', 'predicas', 'eventos', 'galeria', 'testimonios', 'ninos', 'porcarts'].map(module => (
                  <TabsContent key={module} value={module}>
                    <AdminCrudTab
                      module={module}
                      items={(adminData[module] as Record<string, string>[]) || []}
                      fields={getModuleFields(module)}
                      adminCreate={(formData) => adminCreate(module, formData)}
                      adminUpdate={(id, formData) => adminUpdate(module, id, formData)}
                      adminDelete={(id) => adminDelete(module, id)}
                      toast={toast}
                      refreshData={refreshPublicData}
                    />
                  </TabsContent>
                ))}

                {/* ── Donaciones Tab ── */}
                <TabsContent value="donaciones">
                  <AdminDonacionesTab data={data} adminFetch={adminFetch} toast={toast} refreshData={refreshPublicData} />
                </TabsContent>

                {/* ── Oración Tab ── */}
                <TabsContent value="oracion">
                  <AdminOracionTab data={data} adminFetch={adminFetch} toast={toast} refreshData={refreshPublicData} />
                </TabsContent>

                {/* ── Mensajes Tab ── */}
                <TabsContent value="mensajes">
                  <AdminMensajesTab adminFetch={adminFetch} adminDelete={adminDelete} toast={toast} />
                </TabsContent>

                {/* ── Miembros Tab ── */}
                <TabsContent value="miembros">
                  <AdminMiembrosTab adminFetch={adminFetch} adminCreate={adminCreate} adminUpdate={adminUpdate} adminDelete={adminDelete} toast={toast} />
                </TabsContent>
              </Tabs>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ════════════════════════════════════════════════════════════════ */
/*  ADMIN SUB-COMPONENTS                                            */
/* ════════════════════════════════════════════════════════════════ */

function AdminField({
  label,
  name,
  value,
  onChange,
  type = 'text',
  placeholder = '',
}: {
  label: string
  name: string
  value: string | number | boolean
  onChange: (name: string, value: string) => void
  type?: string
  placeholder?: string
}) {
  if (typeof value === 'boolean') {
    return (
      <div className="flex items-center justify-between py-2">
        <Label className="text-[#9A9080] text-xs">{label}</Label>
        <Switch checked={value} onCheckedChange={v => onChange(name, String(v))} />
      </div>
    )
  }
  if (type === 'textarea') {
    return (
      <div>
        <Label className="text-[#9A9080] text-xs mb-1 block">{label}</Label>
        <Textarea
          value={String(value)}
          onChange={e => onChange(name, e.target.value)}
          placeholder={placeholder}
          rows={3}
          className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 text-sm focus:border-[#C9A84C]"
        />
      </div>
    )
  }
  return (
    <div>
      <Label className="text-[#9A9080] text-xs mb-1 block">{label}</Label>
      <Input
        type={type}
        value={String(value)}
        onChange={e => onChange(name, e.target.value)}
        placeholder={placeholder}
        className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 text-sm focus:border-[#C9A84C]"
      />
    </div>
  )
}

function getModuleFields(module: string): { name: string; label: string; type?: string; placeholder?: string }[] {
  const fieldsMap: Record<string, { name: string; label: string; type?: string; placeholder?: string }[]> = {
    horarios: [
      { name: 'dia', label: 'Día', placeholder: 'Domingo' },
      { name: 'servicio', label: 'Servicio', placeholder: 'Servicio Principal' },
      { name: 'hora', label: 'Hora', placeholder: '10:00 AM' },
      { name: 'activo', label: 'Activo' },
      { name: 'orden', label: 'Orden', type: 'number', placeholder: '0' },
    ],
    predicas: [
      { name: 'titulo', label: 'Título *', placeholder: 'Título de la predica' },
      { name: 'serie', label: 'Serie', placeholder: 'General' },
      { name: 'predicador', label: 'Predicador' },
      { name: 'fechaPredica', label: 'Fecha', type: 'date' },
      { name: 'audioUrl', label: 'Audio URL' },
      { name: 'spotifyUrl', label: 'Spotify URL' },
      { name: 'imagenUrl', label: 'Imagen URL' },
      { name: 'publicada', label: 'Publicada' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
    eventos: [
      { name: 'nombre', label: 'Nombre *', placeholder: 'Nombre del evento' },
      { name: 'descripcion', label: 'Descripción', type: 'textarea' },
      { name: 'fechaEvento', label: 'Fecha', type: 'date' },
      { name: 'badge', label: 'Badge', placeholder: 'Evento' },
      { name: 'publicado', label: 'Publicado' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
    galeria: [
      { name: 'imagenUrl', label: 'URL de Imagen *', placeholder: 'https://...' },
      { name: 'caption', label: 'Caption' },
      { name: 'publicada', label: 'Publicada' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
    testimonios: [
      { name: 'texto', label: 'Texto *', type: 'textarea' },
      { name: 'autor', label: 'Autor *' },
      { name: 'publicado', label: 'Publicado' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
    ninos: [
      { name: 'nombre', label: 'Nombre *', placeholder: 'Nombre del recurso' },
      { name: 'tipo', label: 'Tipo', placeholder: 'Libro PDF' },
      { name: 'imagenUrl', label: 'Imagen URL' },
      { name: 'recursoUrl', label: 'URL del Recurso' },
      { name: 'publicado', label: 'Publicado' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
    porcarts: [
      { name: 'texto', label: 'Texto *', type: 'textarea' },
      { name: 'referencia', label: 'Referencia' },
      { name: 'bgUrl', label: 'URL de Fondo' },
      { name: 'activo', label: 'Activo' },
      { name: 'orden', label: 'Orden', type: 'number' },
    ],
  }
  return fieldsMap[module] || []
}

function AdminCrudTab({
  module,
  items,
  fields,
  adminCreate,
  adminUpdate,
  adminDelete,
  toast,
  refreshData,
}: {
  module: string
  items: Record<string, string>[]
  fields: { name: string; label: string; type?: string; placeholder?: string }[]
  adminCreate: (formData: Record<string, unknown>) => Promise<void>
  adminUpdate: (id: string, formData: Record<string, unknown>) => Promise<void>
  adminDelete: (id: string) => Promise<void>
  toast: ReturnType<typeof useToast>['toast']
  refreshData: () => Promise<void>
}) {
  const [formData, setFormData] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {}
    fields.forEach(f => { initial[f.name] = f.type === 'number' ? '0' : '' })
    return initial
  })
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editFormData, setEditFormData] = useState<Record<string, string>>({})

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const data: Record<string, unknown> = { ...formData }
    if (data.orden) data.orden = Number(data.orden)
    if (data.activo !== undefined) data.activo = data.activo === 'true'
    if (data.publicado !== undefined) data.publicado = data.publicado === 'true'
    if (data.publicada !== undefined) data.publicada = data.publicada === 'true'
    await adminCreate(data)
    const reset: Record<string, string> = {}
    fields.forEach(f => { reset[f.name] = f.type === 'number' ? '0' : '' })
    setFormData(reset)
  }

  const handleEdit = (item: Record<string, string>) => {
    setEditingId(item.id)
    const mapped: Record<string, string> = {}
    fields.forEach(f => { mapped[f.name] = String(item[f.name] ?? '') })
    setEditFormData(mapped)
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingId) return
    const data: Record<string, unknown> = { ...editFormData }
    if (data.orden) data.orden = Number(data.orden)
    if (data.activo !== undefined) data.activo = data.activo === 'true'
    if (data.publicado !== undefined) data.publicado = data.publicado === 'true'
    if (data.publicada !== undefined) data.publicada = data.publicada === 'true'
    await adminUpdate(editingId, data)
    setEditingId(null)
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setEditFormData({})
  }

  return (
    <div>
      {/* Add Form */}
      <form onSubmit={handleSubmit} className="glass-card p-4 sm:p-5 mb-6">
        <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Agregar</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {fields.map(f => (
            <div key={f.name} className={f.type === 'textarea' ? 'sm:col-span-2 lg:col-span-3' : ''}>
              <AdminField
                label={f.label}
                name={f.name}
                value={formData[f.name] || (f.type === 'number' ? '0' : '')}
                onChange={(name, value) => setFormData(prev => ({ ...prev, [name]: value }))}
                type={f.type}
                placeholder={f.placeholder}
              />
            </div>
          ))}
        </div>
        <Button type="submit" className="gold-btn mt-4 text-xs">
          <Plus className="w-3 h-3" /> Agregar
        </Button>
      </form>

      {/* List */}
      <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
        {items.length === 0 && (
          <p className="text-[#9A9080] text-sm text-center py-4">No hay elementos</p>
        )}
        {items.map(item => (
          <div key={item.id} className="glass-card p-3">
            {editingId === item.id ? (
              <form onSubmit={handleEditSubmit} className="space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {fields.map(f => (
                    <div key={f.name} className={f.type === 'textarea' ? 'sm:col-span-2' : ''}>
                      <AdminField
                        label={f.label}
                        name={f.name}
                        value={editFormData[f.name] || ''}
                        onChange={(name, value) => setEditFormData(prev => ({ ...prev, [name]: value }))}
                        type={f.type}
                        placeholder={f.placeholder}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button type="submit" className="gold-btn text-xs py-1 px-3">
                    <Save className="w-3 h-3" /> Guardar
                  </Button>
                  <Button type="button" onClick={handleCancelEdit} className="outline-btn text-xs py-1 px-3">
                    Cancelar
                  </Button>
                </div>
              </form>
            ) : (
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-[#E8E2D5] text-sm truncate">
                    {item.nombre || item.titulo || item.texto || item.imagenUrl || 'Sin título'}
                  </p>
                  <p className="text-[#9A9080] text-xs truncate">
                    {[item.dia, item.servicio, item.hora, item.serie, item.predicador, item.tipo, item.fechaPredica, item.fechaEvento, item.referencia, item.autor, item.caption]
                      .filter(Boolean)
                      .join(' · ')}
                  </p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => handleEdit(item)} className="p-1.5 rounded text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-colors">
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => adminDelete(item.id)} className="p-1.5 rounded text-[#9A9080] hover:text-red-400 hover:bg-[rgba(239,68,68,0.1)] transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── Iglesia Tab ── */
function AdminIglesiaTab({
  data,
  adminFetch,
  toast,
  refreshData,
}: {
  data: IglesiaData | null
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  toast: ReturnType<typeof useToast>['toast']
  refreshData: () => Promise<void>
}) {
  const [form, setForm] = useState({
    nombre: data?.iglesia?.nombre || '',
    versiculo: data?.iglesia?.versiculo || '',
    versiculoRef: data?.iglesia?.versiculoRef || '',
    mision: data?.iglesia?.mision || '',
    logoUrl: data?.iglesia?.logoUrl || '',
  })

  const handleSave = async () => {
    try {
      await adminFetch('iglesia?section=main', {
        method: 'PUT',
        body: JSON.stringify(form),
      })
      toast({ title: 'Iglesia actualizada' })
      refreshData()
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error', variant: 'destructive' })
    }
  }

  return (
    <div className="glass-card p-4">
      <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Configuración de Iglesia</h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        <AdminField label="Nombre" name="nombre" value={form.nombre} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
        <AdminField label="Logo URL" name="logoUrl" value={form.logoUrl} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} placeholder="https://..." />
        <AdminField label="Versículo" name="versiculo" value={form.versiculo} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} type="textarea" />
        <AdminField label="Referencia" name="versiculoRef" value={form.versiculoRef} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
        <AdminField label="Misión" name="mision" value={form.mision} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} type="textarea" className="sm:col-span-2 lg:col-span-3" />
      </div>
      <Button onClick={handleSave} className="gold-btn mt-4 text-xs"><Save className="w-3 h-3" /> Guardar</Button>
    </div>
  )
}

/* ── Conócenos Tab ── */
function AdminConocenosTab({
  data,
  adminFetch,
  toast,
  refreshData,
}: {
  data: IglesiaData | null
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  toast: ReturnType<typeof useToast>['toast']
  refreshData: () => Promise<void>
}) {
  const [heroForm, setHeroForm] = useState({
    imagenUrl: data?.hero?.imagenUrl || '',
    footerSlogan: data?.hero?.footerSlogan || '',
    footerAnio: data?.hero?.footerAnio || '',
  })
  const [pastorForm, setPastorForm] = useState({
    nombre: data?.pastor?.nombre || '',
    rol: data?.pastor?.rol || '',
    iniciales: data?.pastor?.iniciales || '',
    fotoUrl: data?.pastor?.fotoUrl || '',
    bio: data?.pastor?.bio || '',
  })

  const handleSaveHero = async () => {
    try {
      await adminFetch('iglesia?section=hero', { method: 'PUT', body: JSON.stringify(heroForm) })
      toast({ title: 'Hero actualizado' })
      refreshData()
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error', variant: 'destructive' })
    }
  }

  const handleSavePastor = async () => {
    try {
      await adminFetch('iglesia?section=pastor', { method: 'PUT', body: JSON.stringify(pastorForm) })
      toast({ title: 'Pastor actualizado' })
      refreshData()
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error', variant: 'destructive' })
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="glass-card p-4">
        <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Hero & Footer</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <AdminField label="Imagen Hero URL" name="imagenUrl" value={heroForm.imagenUrl} onChange={(n, v) => setHeroForm(p => ({ ...p, [n]: v }))} className="sm:col-span-2" />
          <AdminField label="Footer Slogan" name="footerSlogan" value={heroForm.footerSlogan} onChange={(n, v) => setHeroForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Footer Año" name="footerAnio" value={heroForm.footerAnio} onChange={(n, v) => setHeroForm(p => ({ ...p, [n]: v }))} />
        </div>
        <Button onClick={handleSaveHero} className="gold-btn mt-4 text-xs"><Save className="w-3 h-3" /> Guardar Hero</Button>
      </div>
      <div className="glass-card p-4">
        <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Pastor</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <AdminField label="Nombre" name="nombre" value={pastorForm.nombre} onChange={(n, v) => setPastorForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Rol" name="rol" value={pastorForm.rol} onChange={(n, v) => setPastorForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Iniciales" name="iniciales" value={pastorForm.iniciales} onChange={(n, v) => setPastorForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Foto URL" name="fotoUrl" value={pastorForm.fotoUrl} onChange={(n, v) => setPastorForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Biografía" name="bio" value={pastorForm.bio} onChange={(n, v) => setPastorForm(p => ({ ...p, [n]: v }))} type="textarea" className="sm:col-span-2" />
        </div>
        <Button onClick={handleSavePastor} className="gold-btn mt-4 text-xs"><Save className="w-3 h-3" /> Guardar Pastor</Button>
      </div>
    </div>
  )
}

/* ── Donaciones Tab ── */
function AdminDonacionesTab({
  data,
  adminFetch,
  toast,
  refreshData,
}: {
  data: IglesiaData | null
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  toast: ReturnType<typeof useToast>['toast']
  refreshData: () => Promise<void>
}) {
  const [form, setForm] = useState({
    activo: data?.donaciones?.activo || false,
    urlPago: data?.donaciones?.urlPago || '',
    mensaje: data?.donaciones?.mensaje || '',
  })

  const handleSave = async () => {
    try {
      await adminFetch('donaciones', { method: 'PUT', body: JSON.stringify(form) })
      toast({ title: 'Donaciones actualizadas' })
      refreshData()
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error', variant: 'destructive' })
    }
  }

  return (
    <div className="glass-card p-4">
      <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Configuración de Donaciones</h4>
      <div className="space-y-3 max-w-md">
        <AdminField label="Activo" name="activo" value={form.activo} onChange={(n, v) => setForm(p => ({ ...p, [n]: v === 'true' }))} />
        <AdminField label="URL de Pago" name="urlPago" value={form.urlPago} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
        <AdminField label="Mensaje" name="mensaje" value={form.mensaje} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} type="textarea" />
      </div>
      <Button onClick={handleSave} className="gold-btn mt-4 text-xs"><Save className="w-3 h-3" /> Guardar</Button>
    </div>
  )
}

/* ── Oración Tab ── */
function AdminOracionTab({
  data,
  adminFetch,
  toast,
  refreshData,
}: {
  data: IglesiaData | null
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  toast: ReturnType<typeof useToast>['toast']
  refreshData: () => Promise<void>
}) {
  const [form, setForm] = useState({
    activo: data?.oracion?.activo || false,
    whatsapp: data?.oracion?.whatsapp || '',
    descripcion: data?.oracion?.descripcion || '',
  })
  const [diaInput, setDiaInput] = useState('')

  const handleSave = async () => {
    try {
      await adminFetch('oracion', { method: 'PUT', body: JSON.stringify(form) })
      toast({ title: 'Oración actualizada' })
      refreshData()
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : 'Error', variant: 'destructive' })
    }
  }

  return (
    <div className="glass-card p-4">
      <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Configuración de Oración</h4>
      <div className="space-y-3 max-w-md">
        <AdminField label="Activo" name="activo" value={form.activo} onChange={(n, v) => setForm(p => ({ ...p, [n]: v === 'true' }))} />
        <AdminField label="WhatsApp" name="whatsapp" value={form.whatsapp} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
        <AdminField label="Descripción" name="descripcion" value={form.descripcion} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} type="textarea" />
        <div>
          <Label className="text-[#9A9080] text-xs mb-1 block">Días de Oración (separados por coma)</Label>
          <Input
            value={diaInput}
            onChange={e => setDiaInput(e.target.value)}
            placeholder="Lunes, Martes, Miércoles..."
            className="bg-transparent border-[rgba(201,168,76,0.15)] text-[#E8E2D5] placeholder:text-[#9A9080]/50 text-sm focus:border-[#C9A84C]"
          />
        </div>
      </div>
      <Button onClick={handleSave} className="gold-btn mt-4 text-xs"><Save className="w-3 h-3" /> Guardar</Button>
    </div>
  )
}

/* ── Mensajes Tab ── */
function AdminMensajesTab({
  adminFetch,
  adminDelete,
  toast,
}: {
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  adminDelete: (module: string, id: string) => Promise<void>
  toast: ReturnType<typeof useToast>['toast']
}) {
  const [mensajes, setMensajes] = useState<Record<string, string>[]>([])
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    if (!loaded) {
      adminFetch('mensajes').then(data => {
        setMensajes(data as Record<string, string>[])
        setLoaded(true)
      }).catch(() => {
        toast({ title: 'Error al cargar mensajes', variant: 'destructive' })
      })
    }
  }, [loaded, adminFetch, toast])

  const handleMarkRead = async (id: string, leido: boolean) => {
    try {
      await adminFetch('mensajes', { method: 'PUT', body: JSON.stringify({ id, leido: !leido }) })
      setMensajes(prev => prev.map(m => m.id === id ? { ...m, leido: !leido } : m))
    } catch {
      toast({ title: 'Error al actualizar', variant: 'destructive' })
    }
  }

  return (
    <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
      {mensajes.length === 0 && <p className="text-[#9A9080] text-sm text-center py-4">No hay mensajes</p>}
      {mensajes.map(m => (
        <div key={m.id} className="glass-card p-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-[#E8E2D5] text-sm font-medium">{m.nombre}</p>
                {!m.leido && <Badge className="text-xs" style={{ background: '#C9A84C', color: '#0E0C0A' }}>Nuevo</Badge>}
              </div>
              <p className="text-[#9A9080] text-xs">{m.email}{m.telefono ? ` · ${m.telefono}` : ''}</p>
              <p className="text-[#E8E2D5] text-sm mt-1">{m.mensaje}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => handleMarkRead(m.id, m.leido === 'true')} className="p-1.5 rounded text-[#9A9080] hover:text-[#C9A84C] hover:bg-[rgba(201,168,76,0.1)] transition-colors" title={m.leido === 'true' ? 'Marcar no leído' : 'Marcar leído'}>
                <MessageSquare className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => adminDelete('mensajes', m.id)} className="p-1.5 rounded text-[#9A9080] hover:text-red-400 hover:bg-[rgba(239,68,68,0.1)] transition-colors">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

/* ── Miembros Tab ── */
function AdminMiembrosTab({
  adminFetch,
  adminCreate,
  adminUpdate,
  adminDelete,
  toast,
}: {
  adminFetch: (module: string, options?: RequestInit) => Promise<unknown>
  adminCreate: (module: string, formData: Record<string, unknown>) => Promise<void>
  adminUpdate: (module: string, id: string, formData: Record<string, unknown>) => Promise<void>
  adminDelete: (module: string, id: string) => Promise<void>
  toast: ReturnType<typeof useToast>['toast']
}) {
  const [miembros, setMiembros] = useState<Record<string, string>[]>([])
  const [loaded, setLoaded] = useState(false)
  const [form, setForm] = useState({ nombre: '', email: '', telefono: '', direccion: '', ministerio: '' })

  useEffect(() => {
    if (!loaded) {
      adminFetch('miembros').then(data => {
        setMiembros(data as Record<string, string>[])
        setLoaded(true)
      }).catch(() => {
        toast({ title: 'Error al cargar miembros', variant: 'destructive' })
      })
    }
  }, [loaded, adminFetch, toast])

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.nombre) return
    await adminCreate('miembros', form)
    setForm({ nombre: '', email: '', telefono: '', direccion: '', ministerio: '' })
    adminFetch('miembros').then(data => setMiembros(data as Record<string, string>[])).catch(() => {})
  }

  return (
    <div>
      <form onSubmit={handleAdd} className="glass-card p-4 mb-6">
        <h4 className="text-sm font-semibold mb-3 text-[#C9A84C]" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem' }}>Agregar Miembro</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <AdminField label="Nombre *" name="nombre" value={form.nombre} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Email" name="email" value={form.email} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Teléfono" name="telefono" value={form.telefono} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
          <AdminField label="Ministerio" name="ministerio" value={form.ministerio} onChange={(n, v) => setForm(p => ({ ...p, [n]: v }))} />
        </div>
        <Button type="submit" className="gold-btn mt-4 text-xs"><Plus className="w-3 h-3" /> Agregar</Button>
      </form>
      <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
        {miembros.length === 0 && <p className="text-[#9A9080] text-sm text-center py-4">No hay miembros</p>}
        {miembros.map(m => (
          <div key={m.id} className="glass-card p-3 flex items-center justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold shrink-0" style={{ background: 'rgba(201, 168, 76, 0.12)', color: '#C9A84C' }}>
                {(m.nombre || '?').charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="text-[#E8E2D5] text-sm truncate">{m.nombre} {m.apellido || ''}</p>
                <p className="text-[#9A9080] text-xs truncate">{[m.email, m.telefono, m.ministerio].filter(Boolean).join(' · ')}</p>
              </div>
            </div>
            <button onClick={() => adminDelete('miembros', m.id)} className="p-1.5 rounded text-[#9A9080] hover:text-red-400 hover:bg-[rgba(239,68,68,0.1)] transition-colors shrink-0">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
