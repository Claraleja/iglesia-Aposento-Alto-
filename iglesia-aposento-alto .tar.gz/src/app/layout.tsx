import type { Metadata } from "next";
import { DM_Sans, Cormorant_Garamond } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500"],
});

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["400", "600"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  title: "Iglesia Aposento Alto — Donde la presencia de Dios transforma vidas",
  description:
    "Iglesia Aposento Alto: Una comunidad de fe dedicada a llevar la esperanza del evangelio a toda familia. Cultos, eventos, predicas y más.",
  keywords: [
    "Iglesia Aposento Alto",
    "iglesia cristiana",
    "cultos",
    "predicas",
    "eventos",
    "comunidad de fe",
  ],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Iglesia Aposento Alto",
    description: "Donde la presencia de Dios transforma vidas",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className="dark" suppressHydrationWarning>
      <body
        className={`${dmSans.variable} ${cormorant.variable} antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}